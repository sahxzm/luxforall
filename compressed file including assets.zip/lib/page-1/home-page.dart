import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 376;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // homepageMDS (5:529)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xfffcfcfc),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogrouppft6mRa (TyvsX4ZdK48fz7GhJZpfT6)
              padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0.24*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // headerSXi (5:646)
                    margin: EdgeInsets.fromLTRB(2*fem, 0*fem, 0*fem, 14*fem),
                    padding: EdgeInsets.fromLTRB(16.31*fem, 3*fem, 25*fem, 0*fem),
                    width: 375*fem,
                    height: 60*fem,
                    decoration: BoxDecoration (
                      color: Color(0xffe7eaef),
                      gradient: LinearGradient (
                        begin: Alignment(-0, -1),
                        end: Alignment(-0.003, 0.517),
                        colors: <Color>[Color(0xffffd3c1), Color(0x00ffddd0)],
                        stops: <double>[0, 1],
                      ),
                      borderRadius: BorderRadius.only (
                        bottomRight: Radius.circular(20*fem),
                        bottomLeft: Radius.circular(20*fem),
                      ),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // menuDB6 (5:648)
                          margin: EdgeInsets.fromLTRB(0*fem, 6.51*fem, 68.31*fem, 0*fem),
                          width: 23.39*fem,
                          height: 14*fem,
                          child: Image.asset(
                            'assets/page-1/images/menu-Uvk.png',
                            width: 23.39*fem,
                            height: 14*fem,
                          ),
                        ),
                        Container(
                          // screenshot202310200150551Nbi (5:651)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 38*fem, 0*fem),
                          width: 144*fem,
                          height: 66*fem,
                          child: Image.asset(
                            'assets/page-1/images/screenshot-2023-10-20-015055-1-dma.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                        Container(
                          // searchep8 (5:649)
                          margin: EdgeInsets.fromLTRB(0*fem, 9*fem, 20.97*fem, 0*fem),
                          width: 20*fem,
                          height: 20*fem,
                          child: Image.asset(
                            'assets/page-1/images/search-cgG.png',
                            width: 20*fem,
                            height: 20*fem,
                          ),
                        ),
                        Container(
                          // shoppingbagAXa (5:650)
                          margin: EdgeInsets.fromLTRB(0*fem, 10.01*fem, 0*fem, 0*fem),
                          width: 19.03*fem,
                          height: 22.55*fem,
                          child: Image.asset(
                            'assets/page-1/images/shopping-bag-jx4.png',
                            width: 19.03*fem,
                            height: 22.55*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupbdukGqW (Tyvk8wXeiPutJ4XiBpbDUk)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 60*fem),
                    width: 375*fem,
                    height: 1322*fem,
                    child: Stack(
                      children: [
                        Positioned(
                          // newarrivalAAC (5:608)
                          left: 16*fem,
                          top: 626*fem,
                          child: Container(
                            width: 343*fem,
                            height: 696*fem,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // autogroupywwyqGL (TyvnCt5oMBptgZjXZLywWY)
                                  padding: EdgeInsets.fromLTRB(25.95*fem, 0*fem, 23.95*fem, 16.87*fem),
                                  width: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // titleYgY (5:618)
                                        margin: EdgeInsets.fromLTRB(9.05*fem, 0*fem, 5.05*fem, 20.05*fem),
                                        width: double.infinity,
                                        height: 40*fem,
                                        child: Stack(
                                          children: [
                                            Positioned(
                                              // availableforrentF5A (5:619)
                                              left: 0*fem,
                                              top: 0*fem,
                                              child: Align(
                                                child: SizedBox(
                                                  width: 279*fem,
                                                  height: 40*fem,
                                                  child: Text(
                                                    'AVAILABLE FOR RENT',
                                                    textAlign: TextAlign.center,
                                                    style: SafeGoogleFont (
                                                      'Tenor Sans',
                                                      fontSize: 18*ffem,
                                                      fontWeight: FontWeight.w400,
                                                      height: 2.2222222222*ffem/fem,
                                                      letterSpacing: 4*fem,
                                                      color: Color(0xff000000),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Positioned(
                                              // 54C (5:620)
                                              left: 81.5206298828*fem,
                                              top: 28*fem,
                                              child: Align(
                                                child: SizedBox(
                                                  width: 124.96*fem,
                                                  height: 9.25*fem,
                                                  child: Image.asset(
                                                    'assets/page-1/images/-zJt.png',
                                                    width: 124.96*fem,
                                                    height: 9.25*fem,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        // tabyvG (5:621)
                                        width: double.infinity,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              // group13LF2 (5:622)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1.15*fem),
                                              width: double.infinity,
                                              child: Row(
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                children: [
                                                  Container(
                                                    // alldjv (5:623)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 25*fem, 1.28*fem),
                                                    child: Text(
                                                      'All',
                                                      textAlign: TextAlign.center,
                                                      style: SafeGoogleFont (
                                                        'Tenor Sans',
                                                        fontSize: 14*ffem,
                                                        fontWeight: FontWeight.w400,
                                                        height: 1.0599999428*ffem/fem,
                                                        letterSpacing: 1*fem,
                                                        color: Color(0xff212806),
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    // apparelk3r (5:624)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 1.28*fem, 25*fem, 0*fem),
                                                    child: Text(
                                                      'Apparel',
                                                      textAlign: TextAlign.center,
                                                      style: SafeGoogleFont (
                                                        'Tenor Sans',
                                                        fontSize: 14*ffem,
                                                        fontWeight: FontWeight.w400,
                                                        height: 1.0599999428*ffem/fem,
                                                        letterSpacing: 1*fem,
                                                        color: Color(0xff888888),
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    // dressCwS (5:625)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 25*fem, 0*fem),
                                                    child: Text(
                                                      'Dress',
                                                      textAlign: TextAlign.center,
                                                      style: SafeGoogleFont (
                                                        'Tenor Sans',
                                                        fontSize: 14*ffem,
                                                        fontWeight: FontWeight.w400,
                                                        height: 1.0599999428*ffem/fem,
                                                        letterSpacing: 1*fem,
                                                        color: Color(0xff888888),
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    // tshirtWSL (5:626)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 21.1*fem, 0*fem),
                                                    child: Text(
                                                      'Tshirt',
                                                      textAlign: TextAlign.center,
                                                      style: SafeGoogleFont (
                                                        'Tenor Sans',
                                                        fontSize: 14*ffem,
                                                        fontWeight: FontWeight.w400,
                                                        height: 1.0599999428*ffem/fem,
                                                        letterSpacing: 1*fem,
                                                        color: Color(0xff888888),
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    // bagbya (5:627)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                                                    child: Text(
                                                      'Bag',
                                                      textAlign: TextAlign.center,
                                                      style: SafeGoogleFont (
                                                        'Tenor Sans',
                                                        fontSize: 14*ffem,
                                                        fontWeight: FontWeight.w400,
                                                        height: 1.0599999428*ffem/fem,
                                                        letterSpacing: 1*fem,
                                                        color: Color(0xff888888),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Container(
                                              // rectangle327Jsz (5:628)
                                              margin: EdgeInsets.fromLTRB(7.26*fem, 0*fem, 0*fem, 0*fem),
                                              width: 5.66*fem,
                                              height: 5.66*fem,
                                              decoration: BoxDecoration (
                                                color: Color(0xffdd8560),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // autogroupzy6y2oz (TyvkYGC8AtB2RfD4gAzy6Y)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 11.84*fem),
                                  width: double.infinity,
                                  height: 260.16*fem,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // autogroupdhn8A9W (TyvkgFxoQwEZPHxPJQdHN8)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 13*fem, 0.16*fem),
                                        width: 165*fem,
                                        height: double.infinity,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // product6gtY (5:610)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                              width: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                children: [
                                                  Container(
                                                    // autogroupqb7v2hW (Tyvkq63RVaSvH49yA5qb7v)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                                    width: double.infinity,
                                                    height: 200*fem,
                                                    decoration: BoxDecoration (
                                                      image: DecorationImage (
                                                        image: AssetImage (
                                                          'assets/page-1/images/rectangle-325-bg.png',
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Text(
                                                    // wnreversibleangoracardigan8Ek (I5:610;431:892)
                                                    'Burberry sweater',
                                                    textAlign: TextAlign.center,
                                                    style: SafeGoogleFont (
                                                      'Tenor Sans',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w400,
                                                      height: 1.3333333333*ffem/fem,
                                                      color: Color(0xff333333),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Container(
                                              // rs300dayqex (5:611)
                                              margin: EdgeInsets.fromLTRB(6*fem, 0*fem, 0*fem, 0*fem),
                                              child: Text(
                                                'Rs300/day',
                                                style: SafeGoogleFont (
                                                  'Tenor Sans',
                                                  fontSize: 15*ffem,
                                                  fontWeight: FontWeight.w400,
                                                  height: 1.6*ffem/fem,
                                                  color: Color(0xffdd8560),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      TextButton(
                                        // product3iTr (5:612)
                                        onPressed: () {},
                                        style: TextButton.styleFrom (
                                          padding: EdgeInsets.zero,
                                        ),
                                        child: Container(
                                          padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 7.16*fem),
                                          width: 165*fem,
                                          height: double.infinity,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                // autogroupv7egoEQ (TyvmHVT6T3UKMvotoZv7Eg)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 11*fem),
                                                width: double.infinity,
                                                height: 200*fem,
                                                decoration: BoxDecoration (
                                                  image: DecorationImage (
                                                    fit: BoxFit.cover,
                                                    image: AssetImage (
                                                      'assets/page-1/images/rectangle-325-bg-mhA.png',
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                // frame16zC (I5:612;431:891)
                                                margin: EdgeInsets.fromLTRB(27.5*fem, 0*fem, 27.5*fem, 0*fem),
                                                width: double.infinity,
                                                child: Column(
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Text(
                                                      // wnreversibleangoracardiganSoA (I5:612;431:892)
                                                      'Moschino handbag',
                                                      textAlign: TextAlign.center,
                                                      style: SafeGoogleFont (
                                                        'Tenor Sans',
                                                        fontSize: 12*ffem,
                                                        fontWeight: FontWeight.w400,
                                                        height: 1.5*ffem/fem,
                                                        color: Color(0xff333333),
                                                      ),
                                                    ),
                                                    Text(
                                                      // yo6 (I5:612;431:893)
                                                      'Rs300/day',
                                                      style: SafeGoogleFont (
                                                        'Tenor Sans',
                                                        fontSize: 15*ffem,
                                                        fontWeight: FontWeight.w400,
                                                        height: 1.6*ffem/fem,
                                                        color: Color(0xffdd8560),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // autogroupjzsnvyE (TyvmWja2a1Hrha7Gb5jZsN)
                                  width: double.infinity,
                                  height: 283*fem,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // autogroupjhtnrrt (TyvmdEPChoH6ymqibXJhTn)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 13*fem, 0*fem),
                                        width: 165*fem,
                                        height: double.infinity,
                                        child: Stack(
                                          children: [
                                            Positioned(
                                              // rs300dayywW (5:613)
                                              left: 44*fem,
                                              top: 248*fem,
                                              child: Align(
                                                child: SizedBox(
                                                  width: 77*fem,
                                                  height: 24*fem,
                                                  child: Text(
                                                    'Rs300/day',
                                                    style: SafeGoogleFont (
                                                      'Tenor Sans',
                                                      fontSize: 15*ffem,
                                                      fontWeight: FontWeight.w400,
                                                      height: 1.6*ffem/fem,
                                                      color: Color(0xffdd8560),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Positioned(
                                              // product4VQ4 (5:614)
                                              left: 0*fem,
                                              top: 0*fem,
                                              child: Container(
                                                width: 165*fem,
                                                height: 283*fem,
                                                child: Column(
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Container(
                                                      // autogroupeetigUY (TyvmjPsbhkoctKnruneETi)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 23*fem),
                                                      width: double.infinity,
                                                      height: 200*fem,
                                                      decoration: BoxDecoration (
                                                        image: DecorationImage (
                                                          fit: BoxFit.cover,
                                                          image: AssetImage (
                                                            'assets/page-1/images/rectangle-325-bg-UkY.png',
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      // frame1Chn (I5:614;431:891)
                                                      margin: EdgeInsets.fromLTRB(47.5*fem, 0*fem, 47.5*fem, 0*fem),
                                                      width: double.infinity,
                                                      height: 60*fem,
                                                      child: Text(
                                                        'LV cardigan',
                                                        textAlign: TextAlign.center,
                                                        style: SafeGoogleFont (
                                                          'Tenor Sans',
                                                          fontSize: 12*ffem,
                                                          fontWeight: FontWeight.w400,
                                                          height: 1.5*ffem/fem,
                                                          color: Color(0xff333333),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        // product5uMJ (5:617)
                                        width: 165*fem,
                                        height: double.infinity,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // autogroupgrecS6L (Tyvn2dssSk9vhnTu1RGrEC)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 23*fem),
                                              width: double.infinity,
                                              height: 200*fem,
                                              decoration: BoxDecoration (
                                                image: DecorationImage (
                                                  fit: BoxFit.cover,
                                                  image: AssetImage (
                                                    'assets/page-1/images/rectangle-325-bg-aRe.png',
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Container(
                                              // frame1m8c (I5:617;431:891)
                                              margin: EdgeInsets.fromLTRB(47.5*fem, 0*fem, 47.5*fem, 0*fem),
                                              width: double.infinity,
                                              height: 60*fem,
                                              child: Text(
                                                'Hermes bag',
                                                textAlign: TextAlign.center,
                                                style: SafeGoogleFont (
                                                  'Tenor Sans',
                                                  fontSize: 12*ffem,
                                                  fontWeight: FontWeight.w400,
                                                  height: 1.5*ffem/fem,
                                                  color: Color(0xff333333),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // autogroupc7pl4tQ (TyvnZnedaNFEcBzvGvC7pL)
                                  padding: EdgeInsets.fromLTRB(106*fem, 0*fem, 44*fem, 0*fem),
                                  width: double.infinity,
                                  height: 41*fem,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // rs300dayCUp (5:615)
                                        margin: EdgeInsets.fromLTRB(116*fem, 0*fem, 0*fem, 28*fem),
                                        width: 77*fem,
                                        height: 24*fem,
                                        child: Center(
                                          child: Text(
                                            'Rs300/day',
                                            style: SafeGoogleFont (
                                              'Tenor Sans',
                                              fontSize: 15*ffem,
                                              fontWeight: FontWeight.w400,
                                              height: 1.6*ffem/fem,
                                              color: Color(0xffdd8560),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // buttonmsecondaryrightVTv (5:609)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 64.25*fem, 0*fem),
                                        width: double.infinity,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // loadmorecYY (I5:609;746:1891)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.17*fem, 0*fem),
                                              child: Text(
                                                'Explore More',
                                                textAlign: TextAlign.center,
                                                style: SafeGoogleFont (
                                                  'Tenor Sans',
                                                  fontSize: 16*ffem,
                                                  fontWeight: FontWeight.w400,
                                                  height: 1.5*ffem/fem,
                                                  color: Color(0xff000000),
                                                ),
                                              ),
                                            ),
                                            Container(
                                              // forwardarrowX9i (I5:609;746:1895)
                                              width: 13.58*fem,
                                              height: 10.5*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/forward-arrow.png',
                                                width: 13.58*fem,
                                                height: 10.5*fem,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Positioned(
                          // bannerT3N (5:629)
                          left: 0*fem,
                          top: 54*fem,
                          child: Container(
                            width: 375*fem,
                            height: 600*fem,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Container(
                                  // autogroupbualatg (TyvocB5gK4H9mWKxaQBUaL)
                                  width: 408*fem,
                                  height: 612*fem,
                                  decoration: BoxDecoration (
                                    image: DecorationImage (
                                      fit: BoxFit.cover,
                                      image: AssetImage (
                                        'assets/page-1/images/taylor-swift-bb29-2019-feat-billboard-sgbsobhdsjh-1240-removebg-preview-1-bg.png',
                                      ),
                                    ),
                                  ),
                                  child: Stack(
                                    children: [
                                      Positioned(
                                        // ug4 (5:631)
                                        left: 99*fem,
                                        top: 128*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 27*fem,
                                            height: 35*fem,
                                            child: RichText(
                                              text: TextSpan(
                                                style: SafeGoogleFont (
                                                  'Bodoni Moda 28pt',
                                                  fontSize: 30.5936050415*ffem,
                                                  fontWeight: FontWeight.w700,
                                                  height: 1.1249999688*ffem/fem,
                                                  color: Color(0xff333333),
                                                ),
                                                children: [
                                                  TextSpan(
                                                    text: '&',
                                                    style: SafeGoogleFont (
                                                      'Bodoni Moda 28pt',
                                                      fontSize: 30.5936050415*ffem,
                                                      fontWeight: FontWeight.w700,
                                                      height: 1.1249999688*ffem/fem,
                                                      fontStyle: FontStyle.italic,
                                                      color: Color(0xff333333),
                                                    ),
                                                  ),
                                                  TextSpan(
                                                    text: ' ',
                                                    style: SafeGoogleFont (
                                                      'Bodoni Moda 28pt',
                                                      fontSize: 30.5936050415*ffem,
                                                      fontWeight: FontWeight.w700,
                                                      height: 1.1249999688*ffem/fem,
                                                      fontStyle: FontStyle.italic,
                                                      color: Color(0xff333333),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        // fashion4jJ (5:636)
                                        left: 99*fem,
                                        top: 97*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 163*fem,
                                            height: 44*fem,
                                            child: Text(
                                              'FASHION',
                                              style: SafeGoogleFont (
                                                'Abhaya Libre',
                                                fontSize: 38.656414032*ffem,
                                                fontWeight: FontWeight.w400,
                                                height: 1.124999963*ffem/fem,
                                                letterSpacing: 1.2080129385*fem,
                                                color: Color(0xff333333),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        // accessories9kk (5:637)
                                        left: 128*fem,
                                        top: 125*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 249*fem,
                                            height: 44*fem,
                                            child: Text(
                                              'ACCESSORIES',
                                              style: SafeGoogleFont (
                                                'Abhaya Libre',
                                                fontSize: 38.656414032*ffem,
                                                fontWeight: FontWeight.w400,
                                                height: 1.124999963*ffem/fem,
                                                letterSpacing: 1.2080129385*fem,
                                                color: Color(0xff333333),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // autogroupfhhzFon (TyvotVwovzrx4RbuX3fhhz)
                                  padding: EdgeInsets.fromLTRB(0*fem, 14*fem, 0*fem, 0*fem),
                                  width: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: [
                                      Container(
                                        // autogroupcdxvMbv (TyvohkkiKoVtXAfKRrcDXv)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 62*fem, 15.18*fem),
                                        width: 322.33*fem,
                                        height: 47.82*fem,
                                        child: Stack(
                                          children: [
                                            Positioned(
                                              // group12g8Q (5:632)
                                              left: 167.5*fem,
                                              top: 39.81640625*fem,
                                              child: Container(
                                                width: 40*fem,
                                                height: 8*fem,
                                                child: Row(
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Container(
                                                      // rectangle327azU (5:633)
                                                      width: 8*fem,
                                                      height: 8*fem,
                                                      decoration: BoxDecoration (
                                                        color: Color(0xfffcfcfc),
                                                      ),
                                                    ),
                                                    SizedBox(
                                                      width: 8*fem,
                                                    ),
                                                    Container(
                                                      // rectangle328hpC (5:635)
                                                      width: 8*fem,
                                                      height: 8*fem,
                                                      decoration: BoxDecoration (
                                                        border: Border.all(color: Color(0xfffcfcfc)),
                                                      ),
                                                    ),
                                                    SizedBox(
                                                      width: 8*fem,
                                                    ),
                                                    Container(
                                                      // rectangle329RVJ (5:634)
                                                      width: 8*fem,
                                                      height: 8*fem,
                                                      decoration: BoxDecoration (
                                                        border: Border.all(color: Color(0xfffcfcfc)),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            Positioned(
                                              // buttonNfS (5:638)
                                              left: 0*fem,
                                              top: 0*fem,
                                              child: ClipRect(
                                                child: BackdropFilter(
                                                  filter: ImageFilter.blur (
                                                    sigmaX: 2*fem,
                                                    sigmaY: 2*fem,
                                                  ),
                                                  child: Container(
                                                    padding: EdgeInsets.fromLTRB(99.33*fem, 8*fem, 30*fem, 8*fem),
                                                    width: 322.33*fem,
                                                    height: 40*fem,
                                                    decoration: BoxDecoration (
                                                      color: Color(0xfffdbea7),
                                                      borderRadius: BorderRadius.circular(30*fem),
                                                    ),
                                                    child: Text(
                                                      'EXPLORE COLLECTION',
                                                      style: SafeGoogleFont (
                                                        'Tenor Sans',
                                                        fontSize: 16*ffem,
                                                        fontWeight: FontWeight.w400,
                                                        height: 1.5*ffem/fem,
                                                        color: Color(0xfffcfcfc),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        // frame60P4k (5:643)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 71*fem, 0*fem),
                                        width: 1*fem,
                                        height: 3*fem,
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Positioned(
                          // luxuryKj6 (5:644)
                          left: 65*fem,
                          top: 31*fem,
                          child: Align(
                            child: SizedBox(
                              width: 150*fem,
                              height: 44*fem,
                              child: Text(
                                'LUXURY ',
                                style: SafeGoogleFont (
                                  'Abhaya Libre',
                                  fontSize: 38.656414032*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.124999963*ffem/fem,
                                  letterSpacing: 1.2080129385*fem,
                                  color: Color(0xff333333),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // lendrentQEk (5:645)
                          left: 7*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 208*fem,
                              height: 44*fem,
                              child: Text(
                                'LEND/RENT',
                                style: SafeGoogleFont (
                                  'Abhaya Libre',
                                  fontSize: 38.656414032*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.124999963*ffem/fem,
                                  letterSpacing: 1.2080129385*fem,
                                  color: Color(0xff333333),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // brandhDr (5:566)
                    margin: EdgeInsets.fromLTRB(26.65*fem, 0*fem, 20.83*fem, 0*fem),
                    width: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // autogrouperraQPA (TyvurfLMJ7i1vEBrEPERRa)
                          padding: EdgeInsets.fromLTRB(3.59*fem, 0*fem, 3.59*fem, 22.38*fem),
                          width: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // devideriPr (5:607)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4.82*fem, 34.44*fem),
                                width: 124.96*fem,
                                height: 9.25*fem,
                                child: Image.asset(
                                  'assets/page-1/images/devider-Lbr.png',
                                  width: 124.96*fem,
                                  height: 9.25*fem,
                                ),
                              ),
                              Container(
                                // autogroup27k6Esz (TyvsmZ9UguBTDwkTwF27K6)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 21.64*fem, 0*fem),
                                width: double.infinity,
                                height: 19.73*fem,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // autogroupjdylwXW (Tyvsty6nwjwD2gt16fjdYL)
                                      padding: EdgeInsets.fromLTRB(0*fem, 3.16*fem, 38.47*fem, 5.87*fem),
                                      height: double.infinity,
                                      child: Row(
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Container(
                                            // pradasg4 (5:601)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 40.99*fem, 0*fem),
                                            height: double.infinity,
                                            child: Row(
                                              crossAxisAlignment: CrossAxisAlignment.center,
                                              children: [
                                                Container(
                                                  // vectorDE8 (5:602)
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0.14*fem, 2.19*fem, 0*fem),
                                                  width: 11.56*fem,
                                                  height: 10.55*fem,
                                                  child: Image.asset(
                                                    'assets/page-1/images/vector-EAL.png',
                                                    width: 11.56*fem,
                                                    height: 10.55*fem,
                                                  ),
                                                ),
                                                Container(
                                                  // vector8rt (5:603)
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0.09*fem, 1.53*fem, 0*fem),
                                                  width: 13.06*fem,
                                                  height: 10.58*fem,
                                                  child: Image.asset(
                                                    'assets/page-1/images/vector.png',
                                                    width: 13.06*fem,
                                                    height: 10.58*fem,
                                                  ),
                                                ),
                                                Container(
                                                  // vectors3n (5:604)
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1.4*fem, 0.03*fem),
                                                  width: 13.24*fem,
                                                  height: 10.46*fem,
                                                  child: Image.asset(
                                                    'assets/page-1/images/vector-73e.png',
                                                    width: 13.24*fem,
                                                    height: 10.46*fem,
                                                  ),
                                                ),
                                                Container(
                                                  // vectorAYg (5:606)
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1.45*fem, 0.09*fem),
                                                  width: 11.64*fem,
                                                  height: 10.6*fem,
                                                  child: Image.asset(
                                                    'assets/page-1/images/vector-AZv.png',
                                                    width: 11.64*fem,
                                                    height: 10.6*fem,
                                                  ),
                                                ),
                                                Container(
                                                  // vectorU3a (5:605)
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0.03*fem, 0*fem, 0*fem),
                                                  width: 13.24*fem,
                                                  height: 10.49*fem,
                                                  child: Image.asset(
                                                    'assets/page-1/images/vector-1XW.png',
                                                    width: 13.24*fem,
                                                    height: 10.49*fem,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Container(
                                            // burberry13W (5:600)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0.45*fem, 0*fem, 0*fem),
                                            width: 98.32*fem,
                                            height: 7.31*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/burberry.png',
                                              width: 98.32*fem,
                                              height: 7.31*fem,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Container(
                                      // bossvwA (5:587)
                                      height: double.infinity,
                                      child: Row(
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Container(
                                            // autogroupf2autNC (TyvtE3PLvppXuEMDWGf2aU)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0.25*fem, 0.75*fem, 0*fem),
                                            width: 12.44*fem,
                                            height: 19.38*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/auto-group-f2au.png',
                                              width: 12.44*fem,
                                              height: 19.38*fem,
                                            ),
                                          ),
                                          Container(
                                            // autogroupwgq8akp (TyvtTx9qKTZXzBDCg8wgQ8)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1.72*fem, 0.02*fem),
                                            width: 15.12*fem,
                                            height: 19.71*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/auto-group-wgq8.png',
                                              width: 15.12*fem,
                                              height: 19.71*fem,
                                            ),
                                          ),
                                          Container(
                                            // autogroupemagUrC (Tyvtf2fi4VPKu5w6TWEmAg)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0.11*fem, 1.93*fem, 0*fem),
                                            width: 10.49*fem,
                                            height: 19.62*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/auto-group-emag.png',
                                              width: 10.49*fem,
                                              height: 19.62*fem,
                                            ),
                                          ),
                                          Container(
                                            // autogroupmsxiPiG (TyvtrSWMwMfrBeSHw3mSXi)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0.11*fem, 0*fem, 0*fem),
                                            width: 10.16*fem,
                                            height: 19.62*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/auto-group-msxi.png',
                                              width: 10.16*fem,
                                              height: 19.62*fem,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // autogroup9umvugc (TyvuT6BHzFbq1Pg1yQ9UMv)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 41.71*fem),
                          width: double.infinity,
                          height: 20.01*fem,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // catiere8Q (5:586)
                                width: 72.17*fem,
                                height: 20.01*fem,
                                child: Image.asset(
                                  'assets/page-1/images/catier.png',
                                  width: 72.17*fem,
                                  height: 20.01*fem,
                                ),
                              ),
                              Container(
                                // autogroupvcdenVW (TyvuZAqVhkWfKXgLN7vcDE)
                                padding: EdgeInsets.fromLTRB(43.76*fem, 5.27*fem, 0*fem, 0.02*fem),
                                height: double.infinity,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  children: [
                                    Container(
                                      // gucci6WC (5:580)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 19.97*fem, 0*fem),
                                      height: double.infinity,
                                      child: Row(
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Container(
                                            // vectordFE (5:582)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8.59*fem, 0.06*fem),
                                            width: 14.71*fem,
                                            height: 14.65*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/vector-qAQ.png',
                                              width: 14.71*fem,
                                              height: 14.65*fem,
                                            ),
                                          ),
                                          Container(
                                            // vectorkKr (5:583)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0.29*fem, 8.41*fem, 0*fem),
                                            width: 13.47*fem,
                                            height: 13.94*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/vector-FKW.png',
                                              width: 13.47*fem,
                                              height: 13.94*fem,
                                            ),
                                          ),
                                          Container(
                                            // vectorGoz (5:584)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 9.18*fem, 0*fem),
                                            width: 13.94*fem,
                                            height: 14.71*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/vector-b3e.png',
                                              width: 13.94*fem,
                                              height: 14.71*fem,
                                            ),
                                          ),
                                          Container(
                                            // vectoroZ2 (5:585)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0.06*fem, 8.71*fem, 0*fem),
                                            width: 13.94*fem,
                                            height: 14.65*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/vector-CxQ.png',
                                              width: 13.94*fem,
                                              height: 14.65*fem,
                                            ),
                                          ),
                                          Container(
                                            // vectorhPW (5:581)
                                            width: 3.29*fem,
                                            height: 13.65*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/vector-H76.png',
                                              width: 3.29*fem,
                                              height: 13.65*fem,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Container(
                                      // tiffanycor1W (5:568)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1.34*fem),
                                      width: 98.36*fem,
                                      height: 12.65*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/tiffany-co.png',
                                        width: 98.36*fem,
                                        height: 12.65*fem,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // deviderJu6 (5:567)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4.82*fem, 0*fem),
                          width: 124.96*fem,
                          height: 9.25*fem,
                          child: Image.asset(
                            'assets/page-1/images/devider.png',
                            width: 124.96*fem,
                            height: 9.25*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupzgk2dgU (TyvpFaB2j6WfAskx5hzgK2)
              width: double.infinity,
              height: 1316*fem,
              child: Stack(
                children: [
                  Positioned(
                    // openfashionBhz (5:530)
                    left: 0.4925537109*fem,
                    top: 524.4423828125*fem,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(27.81*fem, 27.56*fem, 15.4*fem, 28.4*fem),
                      width: 376.91*fem,
                      height: 465*fem,
                      decoration: BoxDecoration (
                        color: Color(0x7ff2f2f2),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // screenshot202310200150552qnY (5:548)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 18.3*fem, 11.17*fem),
                            width: 166*fem,
                            height: 45*fem,
                            child: Image.asset(
                              'assets/page-1/images/screenshot-2023-10-20-015055-2.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                          Container(
                            // group27x6U (5:532)
                            width: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // autogroupvytxJg8 (Tyvq7DQyrbBWnw9QHzvYtx)
                                  padding: EdgeInsets.fromLTRB(0.7*fem, 0*fem, 0.7*fem, 14.12*fem),
                                  width: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // makingaluxuriouslifestyleacces (5:533)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 15.3*fem, 10.57*fem),
                                        constraints: BoxConstraints (
                                          maxWidth: 270*fem,
                                        ),
                                        child: Text(
                                          'Making a luxurious lifestyle accessible for everyone and lowest price possible.\nEveryone has right to be luxurious....',
                                          textAlign: TextAlign.center,
                                          style: SafeGoogleFont (
                                            'Tenor Sans',
                                            fontSize: 14*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.4285714286*ffem/fem,
                                            letterSpacing: 0.14*fem,
                                            color: Color(0xff555555),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // 5KW (5:541)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 20.3*fem, 13.6*fem),
                                        width: 124.96*fem,
                                        height: 9.25*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/-7oW.png',
                                          width: 124.96*fem,
                                          height: 9.25*fem,
                                        ),
                                      ),
                                      Container(
                                        // autogrouphe9nan4 (TyvpdtsAn5PcBX6PVXhe9N)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8.41*fem, 0*fem),
                                        width: double.infinity,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.end,
                                          children: [
                                            Container(
                                              // group23Ji4 (5:534)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 36.89*fem, 3.92*fem),
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                children: [
                                                  Container(
                                                    // miroodlesstickerrDn (5:536)
                                                    margin: EdgeInsets.fromLTRB(3.86*fem, 0*fem, 0*fem, 11.96*fem),
                                                    width: 49.77*fem,
                                                    height: 34.91*fem,
                                                    child: Image.asset(
                                                      'assets/page-1/images/miroodles-sticker-o1i.png',
                                                      fit: BoxFit.contain,
                                                    ),
                                                  ),
                                                  Container(
                                                    // freepickupfromyourdoorserviceN (5:535)
                                                    constraints: BoxConstraints (
                                                      maxWidth: 139*fem,
                                                    ),
                                                    child: Text(
                                                      'Free pickup from your door service.',
                                                      textAlign: TextAlign.center,
                                                      style: SafeGoogleFont (
                                                        'Tenor Sans',
                                                        fontSize: 13*ffem,
                                                        fontWeight: FontWeight.w400,
                                                        height: 1.5384615385*ffem/fem,
                                                        color: Color(0xff555555),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Container(
                                              // group22UW4 (5:537)
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                children: [
                                                  Container(
                                                    // miroodlesstickerooE (5:539)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 11.63*fem, 8.9*fem),
                                                    width: 52.45*fem,
                                                    height: 36.8*fem,
                                                    child: Image.asset(
                                                      'assets/page-1/images/miroodles-sticker-Z8k.png',
                                                      fit: BoxFit.contain,
                                                    ),
                                                  ),
                                                  Container(
                                                    // noworryabouthyiginedrycleanedp (5:538)
                                                    constraints: BoxConstraints (
                                                      maxWidth: 148*fem,
                                                    ),
                                                    child: Text(
                                                      'No worry about hyigine\nDrycleaned product',
                                                      textAlign: TextAlign.center,
                                                      style: SafeGoogleFont (
                                                        'Tenor Sans',
                                                        fontSize: 13*ffem,
                                                        fontWeight: FontWeight.w400,
                                                        height: 1.5384615385*ffem/fem,
                                                        color: Color(0xff555555),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // autogroupuwxgQo2 (TyvpqZCQWKXBFKS4jhuWxG)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 33.17*fem),
                                  width: double.infinity,
                                  height: 81.8*fem,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // group6vWU (5:542)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 21.7*fem, 0*fem),
                                        height: double.infinity,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // miroodlesstickerGKS (5:544)
                                              margin: EdgeInsets.fromLTRB(0.5*fem, 0*fem, 0*fem, 3.67*fem),
                                              width: 54.35*fem,
                                              height: 38.13*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/miroodles-sticker-XCt.png',
                                                fit: BoxFit.contain,
                                              ),
                                            ),
                                            Container(
                                              // qualityassuranceandmultipleche (5:543)
                                              constraints: BoxConstraints (
                                                maxWidth: 141*fem,
                                              ),
                                              child: Text(
                                                'Quality assurance\nand multiple checking.',
                                                textAlign: TextAlign.center,
                                                style: SafeGoogleFont (
                                                  'Tenor Sans',
                                                  fontSize: 13*ffem,
                                                  fontWeight: FontWeight.w400,
                                                  height: 1.5384615385*ffem/fem,
                                                  color: Color(0xff555555),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        // group21TPv (5:545)
                                        height: double.infinity,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // miroodlesstickerR5r (5:547)
                                              margin: EdgeInsets.fromLTRB(0.5*fem, 0*fem, 0*fem, 3.67*fem),
                                              width: 54.35*fem,
                                              height: 38.13*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/miroodles-sticker.png',
                                                fit: BoxFit.contain,
                                              ),
                                            ),
                                            Container(
                                              // fastshippingfreeonordersoverrs (5:546)
                                              constraints: BoxConstraints (
                                                maxWidth: 171*fem,
                                              ),
                                              child: Text(
                                                'Fast shipping. \nFree on orders over Rs500.',
                                                textAlign: TextAlign.center,
                                                style: SafeGoogleFont (
                                                  'Tenor Sans',
                                                  fontSize: 13*ffem,
                                                  fontWeight: FontWeight.w400,
                                                  height: 1.5384615385*ffem/fem,
                                                  color: Color(0xff555555),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // 2rL (5:540)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 13.03*fem, 0*fem),
                                  width: 66.52*fem,
                                  height: 39.56*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/-t1n.png',
                                    width: 66.52*fem,
                                    height: 39.56*fem,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // productM7v (5:549)
                    left: 1*fem,
                    top: 0*fem,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(16.37*fem, 23*fem, 0*fem, 20.12*fem),
                      width: 375*fem,
                      height: 531*fem,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            // titileFj6 (5:563)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16.37*fem, 23.06*fem),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Text(
                                  // listyourownproductb2G (5:565)
                                  'LIST YOUR OWN PRODUCT',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Tenor Sans',
                                    fontSize: 18*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 2.2222222222*ffem/fem,
                                    letterSpacing: 4*fem,
                                    color: Color(0xff000000),
                                  ),
                                ),
                                Container(
                                  // Wuv (5:564)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                                  width: 124.96*fem,
                                  height: 9.25*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/-F6Q.png',
                                    width: 124.96*fem,
                                    height: 9.25*fem,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // group17JKz (5:554)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 17.57*fem),
                            width: double.infinity,
                            height: 390*fem,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // productDSx (5:555)
                                  padding: EdgeInsets.fromLTRB(0*fem, 0.27*fem, 0*fem, 14.09*fem),
                                  width: 255*fem,
                                  height: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // rectangle321kBz (5:556)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0.57*fem, 16*fem),
                                        width: 254.89*fem,
                                        height: 311.64*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/rectangle-321-JRE.png',
                                        ),
                                      ),
                                      Container(
                                        // frame1snQ (5:557)
                                        margin: EdgeInsets.fromLTRB(83*fem, 0*fem, 83*fem, 0*fem),
                                        width: double.infinity,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // handbagsDrG (5:558)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                                              child: Text(
                                                'Handbags',
                                                textAlign: TextAlign.center,
                                                style: SafeGoogleFont (
                                                  'Tenor Sans',
                                                  fontSize: 16*ffem,
                                                  fontWeight: FontWeight.w400,
                                                  height: 1.5*ffem/fem,
                                                  color: Color(0xff333333),
                                                ),
                                              ),
                                            ),
                                            Text(
                                              // rs1001000MBn (5:559)
                                              'Rs 100-1000',
                                              style: SafeGoogleFont (
                                                'Tenor Sans',
                                                fontSize: 16*ffem,
                                                fontWeight: FontWeight.w400,
                                                height: 1.5*ffem/fem,
                                                color: Color(0xffdd8560),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // autogroup48etVHz (TyvqoCGN4rVBb6t1RB48Et)
                                  padding: EdgeInsets.fromLTRB(9.53*fem, 0.54*fem, 0*fem, 0.54*fem),
                                  height: double.infinity,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // productQA4 (5:560)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.11*fem, 0*fem),
                                        width: 254.89*fem,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // rectangle321wQt (I5:560;5:556)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                              width: 254.89*fem,
                                              height: 311.64*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/rectangle-321.png',
                                                fit: BoxFit.cover,
                                              ),
                                            ),
                                            Container(
                                              // frame1sJY (I5:560;5:557)
                                              margin: EdgeInsets.fromLTRB(83.47*fem, 0*fem, 82.43*fem, 0*fem),
                                              width: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                children: [
                                                  Container(
                                                    // handbagsP1z (I5:560;5:558)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                                                    child: Text(
                                                      'Jackets',
                                                      textAlign: TextAlign.center,
                                                      style: SafeGoogleFont (
                                                        'Tenor Sans',
                                                        fontSize: 16*ffem,
                                                        fontWeight: FontWeight.w400,
                                                        height: 1.5*ffem/fem,
                                                        color: Color(0xff333333),
                                                      ),
                                                    ),
                                                  ),
                                                  Text(
                                                    // rs1001000Jue (I5:560;5:559)
                                                    'Rs 100-1000',
                                                    style: SafeGoogleFont (
                                                      'Tenor Sans',
                                                      fontSize: 16*ffem,
                                                      fontWeight: FontWeight.w400,
                                                      height: 1.5*ffem/fem,
                                                      color: Color(0xffdd8560),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        // productdS8 (5:561)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.11*fem, 0*fem),
                                        width: 254.89*fem,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // rectangle321Zqa (I5:561;5:556)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                              width: 254.89*fem,
                                              height: 311.64*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/rectangle-321-P9a.png',
                                              ),
                                            ),
                                            Container(
                                              // frame1HFn (I5:561;5:557)
                                              margin: EdgeInsets.fromLTRB(67.97*fem, 0*fem, 66.93*fem, 0*fem),
                                              width: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                children: [
                                                  Text(
                                                    // trouserscYx (I5:561;5:558)
                                                    'Shoes, Trousers',
                                                    textAlign: TextAlign.center,
                                                    style: SafeGoogleFont (
                                                      'Tenor Sans',
                                                      fontSize: 16*ffem,
                                                      fontWeight: FontWeight.w400,
                                                      height: 1.5*ffem/fem,
                                                      color: Color(0xff333333),
                                                    ),
                                                  ),
                                                  Container(
                                                    // rs1001000N2L (I5:561;5:559)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                                                    child: Text(
                                                      'Rs 100-1000',
                                                      style: SafeGoogleFont (
                                                        'Tenor Sans',
                                                        fontSize: 16*ffem,
                                                        fontWeight: FontWeight.w400,
                                                        height: 1.5*ffem/fem,
                                                        color: Color(0xffdd8560),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        // product6DE (5:562)
                                        width: 254.89*fem,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // rectangle3213eG (I5:562;5:556)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                              width: 254.89*fem,
                                              height: 311.64*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/rectangle-321-NSC.png',
                                                fit: BoxFit.cover,
                                              ),
                                            ),
                                            Container(
                                              // frame1ZMi (I5:562;5:557)
                                              margin: EdgeInsets.fromLTRB(78.97*fem, 0*fem, 77.93*fem, 0*fem),
                                              width: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                children: [
                                                  Text(
                                                    // handbagstPz (I5:562;5:558)
                                                    'Tshirts,Shirts',
                                                    textAlign: TextAlign.center,
                                                    style: SafeGoogleFont (
                                                      'Tenor Sans',
                                                      fontSize: 16*ffem,
                                                      fontWeight: FontWeight.w400,
                                                      height: 1.5*ffem/fem,
                                                      color: Color(0xff333333),
                                                    ),
                                                  ),
                                                  Container(
                                                    // rs1001000cat (I5:562;5:559)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                                                    child: Text(
                                                      'Rs 100-1000',
                                                      style: SafeGoogleFont (
                                                        'Tenor Sans',
                                                        fontSize: 16*ffem,
                                                        fontWeight: FontWeight.w400,
                                                        height: 1.5*ffem/fem,
                                                        color: Color(0xffdd8560),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // indicatorwNG (5:550)
                            margin: EdgeInsets.fromLTRB(154.03*fem, 0*fem, 170.4*fem, 0*fem),
                            width: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // rectangle327smi (5:551)
                                  width: 8*fem,
                                  height: 8*fem,
                                  decoration: BoxDecoration (
                                    color: Color(0xff888888),
                                  ),
                                ),
                                SizedBox(
                                  width: 5.1*fem,
                                ),
                                Container(
                                  // rectangle328DKn (5:553)
                                  width: 8*fem,
                                  height: 8*fem,
                                  decoration: BoxDecoration (
                                    border: Border.all(color: Color(0xff888888)),
                                  ),
                                ),
                                SizedBox(
                                  width: 5.1*fem,
                                ),
                                Container(
                                  // rectangle329xHN (5:552)
                                  width: 8*fem,
                                  height: 8*fem,
                                  decoration: BoxDecoration (
                                    border: Border.all(color: Color(0xff888888)),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // footeruTW (5:652)
                    left: 0*fem,
                    top: 976*fem,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                      width: 375*fem,
                      height: 340*fem,
                      decoration: BoxDecoration (
                        color: Color(0xffffffff),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // autogroupaamvBR2 (Tyvs2zY4gQod2yiFCCaAMv)
                            padding: EdgeInsets.fromLTRB(29*fem, 23.78*fem, 30*fem, 22.97*fem),
                            width: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // group29uM2 (I5:652;639:716)
                                  margin: EdgeInsets.fromLTRB(77.5*fem, 0*fem, 76.5*fem, 24*fem),
                                  padding: EdgeInsets.fromLTRB(1.6*fem, 2.4*fem, 1.6*fem, 2.4*fem),
                                  width: double.infinity,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // twitterQYg (I5:652;560:875)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                                        width: 20.8*fem,
                                        height: 16.9*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/twitter-Z6p.png',
                                          width: 20.8*fem,
                                          height: 16.9*fem,
                                        ),
                                      ),
                                      SizedBox(
                                        width: 49*fem,
                                      ),
                                      Container(
                                        // instagram6Ac (I5:652;560:877)
                                        width: 19.2*fem,
                                        height: 19.2*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/instagram.png',
                                          width: 19.2*fem,
                                          height: 19.2*fem,
                                        ),
                                      ),
                                      SizedBox(
                                        width: 49*fem,
                                      ),
                                      Container(
                                        // youtubez16 (I5:652;560:881)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                                        width: 20.8*fem,
                                        height: 17.6*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/youtube-mHr.png',
                                          width: 20.8*fem,
                                          height: 17.6*fem,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // iBz (I5:652;585:713)
                                  margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 18.73*fem),
                                  width: 124.96*fem,
                                  height: 9.25*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/-JTr.png',
                                    width: 124.96*fem,
                                    height: 9.25*fem,
                                  ),
                                ),
                                Container(
                                  // autogroupp1rqFBv (TyvrdAtRXArPLuMwAap1rQ)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 30.02*fem),
                                  width: double.infinity,
                                  height: 118*fem,
                                  child: Stack(
                                    children: [
                                      Positioned(
                                        // N1e (I5:652;651:912)
                                        left: 96.0206298828*fem,
                                        top: 106.7641601562*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 124.96*fem,
                                            height: 9.25*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/-11z.png',
                                              width: 124.96*fem,
                                              height: 9.25*fem,
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        // supportopenuidesign60825876080 (I5:652;560:899)
                                        left: 0*fem,
                                        top: 0*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 316*fem,
                                            height: 118*fem,
                                            child: Text(
                                              'connect us at : sahilsigh0322@gmail.com\n+88043****77\n24/7 - Everyday\nI have nothing to do i’m super free\n',
                                              textAlign: TextAlign.center,
                                              style: SafeGoogleFont (
                                                'Tenor Sans',
                                                fontSize: 16*ffem,
                                                fontWeight: FontWeight.w400,
                                                height: 1.8399999142*ffem/fem,
                                                color: Color(0xff333333),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // autogroupsm4tXYk (TyvriLQV7czi8VyAQKSm4t)
                                  margin: EdgeInsets.fromLTRB(29*fem, 0*fem, 40*fem, 0*fem),
                                  width: double.infinity,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Text(
                                        // aboutrb2 (I5:652;560:885)
                                        'About',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Tenor Sans',
                                          fontSize: 16*ffem,
                                          fontWeight: FontWeight.w400,
                                          height: 1.5*ffem/fem,
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                      SizedBox(
                                        width: 52*fem,
                                      ),
                                      Text(
                                        // contactbHi (I5:652;560:886)
                                        'Contact',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Tenor Sans',
                                          fontSize: 16*ffem,
                                          fontWeight: FontWeight.w400,
                                          height: 1.5*ffem/fem,
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                      SizedBox(
                                        width: 52*fem,
                                      ),
                                      TextButton(
                                        // blogi7S (I5:652;560:887)
                                        onPressed: () {},
                                        style: TextButton.styleFrom (
                                          padding: EdgeInsets.zero,
                                        ),
                                        child: Text(
                                          'Blog',
                                          textAlign: TextAlign.center,
                                          style: SafeGoogleFont (
                                            'Tenor Sans',
                                            fontSize: 16*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.5*ffem/fem,
                                            color: Color(0xff000000),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // autogrouplggy39i (TyvrsQyh3e47oW1E2dLGGY)
                            width: double.infinity,
                            height: 45.25*fem,
                            decoration: BoxDecoration (
                              color: Color(0x19c4c4c4),
                            ),
                            child: Center(
                              child: Text(
                                'Thanks for visiting i hope you liked our product UI :)',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Tenor Sans',
                                  fontSize: 12*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.5849998792*ffem/fem,
                                  color: Color(0xff555555),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}