import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // checkoutkUp (5:1114)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroupv9ra4VW (TywCCGwinq3TBDeEBmV9RA)
              padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 24.63*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // headeraik (5:1181)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 35.75*fem),
                    padding: EdgeInsets.fromLTRB(16.31*fem, 3*fem, 25*fem, 0*fem),
                    width: double.infinity,
                    height: 60*fem,
                    decoration: BoxDecoration (
                      color: Color(0xffe7eaef),
                      gradient: LinearGradient (
                        begin: Alignment(-0, -1),
                        end: Alignment(-0.003, 0.517),
                        colors: <Color>[Color(0xffffd3c1), Color(0x00ffddd0)],
                        stops: <double>[0, 1],
                      ),
                      borderRadius: BorderRadius.only (
                        bottomRight: Radius.circular(20*fem),
                        bottomLeft: Radius.circular(20*fem),
                      ),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // menuoLc (5:1183)
                          margin: EdgeInsets.fromLTRB(0*fem, 6.51*fem, 68.31*fem, 0*fem),
                          width: 23.39*fem,
                          height: 14*fem,
                          child: Image.asset(
                            'assets/page-1/images/menu-FsW.png',
                            width: 23.39*fem,
                            height: 14*fem,
                          ),
                        ),
                        Container(
                          // screenshot202310200150551WVv (5:1186)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 38*fem, 0*fem),
                          child: TextButton(
                            onPressed: () {},
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Container(
                              width: 144*fem,
                              height: 66*fem,
                              child: Image.asset(
                                'assets/page-1/images/screenshot-2023-10-20-015055-1-Hyz.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                        Container(
                          // searchy8c (5:1184)
                          margin: EdgeInsets.fromLTRB(0*fem, 9*fem, 20.97*fem, 0*fem),
                          width: 20*fem,
                          height: 20*fem,
                          child: Image.asset(
                            'assets/page-1/images/search.png',
                            width: 20*fem,
                            height: 20*fem,
                          ),
                        ),
                        Container(
                          // shoppingbagG7i (5:1185)
                          margin: EdgeInsets.fromLTRB(0*fem, 10.01*fem, 0*fem, 0*fem),
                          width: 19.03*fem,
                          height: 22.55*fem,
                          child: Image.asset(
                            'assets/page-1/images/shopping-bag-QKi.png',
                            width: 19.03*fem,
                            height: 22.55*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupr6hnn64 (TywBwsC4hScMXo7HUdr6hn)
                    margin: EdgeInsets.fromLTRB(118.83*fem, 0*fem, 117.17*fem, 16.59*fem),
                    width: double.infinity,
                    height: 41.83*fem,
                    child: Stack(
                      children: [
                        Positioned(
                          // checkout6cY (5:1116)
                          left: 0*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 139*fem,
                              height: 40*fem,
                              child: Text(
                                'CHECKOUT',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Tenor Sans',
                                  fontSize: 18*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 2.2222222222*ffem/fem,
                                  letterSpacing: 4*fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // P5r (5:1117)
                          left: 7.020690918*fem,
                          top: 32.5759277344*fem,
                          child: Align(
                            child: SizedBox(
                              width: 124.96*fem,
                              height: 9.25*fem,
                              child: Image.asset(
                                'assets/page-1/images/-5E8.png',
                                width: 124.96*fem,
                                height: 9.25*fem,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // group251V8t (5:1126)
                    margin: EdgeInsets.fromLTRB(16*fem, 0*fem, 17*fem, 36*fem),
                    width: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // autogroupjuykRoE (TywCamJFQj9mNgsKSgJuYk)
                          padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                          width: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                // shippingadressy44 (5:1127)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 11.83*fem),
                                child: Text(
                                  'SHIPPING ADRESS',
                                  style: SafeGoogleFont (
                                    'Tenor Sans',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1428571429*ffem/fem,
                                    letterSpacing: 1*fem,
                                    color: Color(0xff888888),
                                  ),
                                ),
                              ),
                              Container(
                                // group250EEt (5:1128)
                                margin: EdgeInsets.fromLTRB(18.34*fem, 0*fem, 27.7*fem, 0*fem),
                                width: double.infinity,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      // cassiedonkkj2 (5:1131)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 6.84*fem),
                                      child: Text(
                                        'Sahil Singh',
                                        style: SafeGoogleFont (
                                          'Tenor Sans',
                                          fontSize: 18*ffem,
                                          fontWeight: FontWeight.w400,
                                          height: 0.8888888889*ffem/fem,
                                          color: Color(0xff1a1a1a),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // autogroupnqbweZW (TywChqvnXjSnonDYuvnqBW)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 17.1*fem),
                                      width: double.infinity,
                                      child: Row(
                                        crossAxisAlignment: CrossAxisAlignment.end,
                                        children: [
                                          Container(
                                            // bbakerstmarylAGx (5:1129)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 67.16*fem, 7.77*fem),
                                            child: Text(
                                              'ina mina dika road, sandook gali ',
                                              style: SafeGoogleFont (
                                                'Tenor Sans',
                                                fontSize: 14*ffem,
                                                fontWeight: FontWeight.w400,
                                                height: 1.5714285714*ffem/fem,
                                                color: Color(0xff555555),
                                              ),
                                            ),
                                          ),
                                          Container(
                                            // forward5ep (5:1132)
                                            width: 5.8*fem,
                                            height: 11.61*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/forward.png',
                                              width: 5.8*fem,
                                              height: 11.61*fem,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Text(
                                      // bbakerstmarylcPr (5:1130)
                                      '333333333',
                                      style: SafeGoogleFont (
                                        'Tenor Sans',
                                        fontSize: 14*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.5714285714*ffem/fem,
                                        color: Color(0xff555555),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // frame42Y2c (5:1133)
                          padding: EdgeInsets.fromLTRB(20*fem, 13*fem, 22.5*fem, 12*fem),
                          width: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0xfff8f8f8),
                            borderRadius: BorderRadius.circular(44*fem),
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // bbakerstmarylrZ6 (5:1134)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 67.35*fem, 1*fem),
                                child: Text(
                                  'Add shipping adress',
                                  style: SafeGoogleFont (
                                    'Tenor Sans',
                                    fontSize: 16*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.375*ffem/fem,
                                    color: Color(0xff555555),
                                  ),
                                ),
                              ),
                              Container(
                                // group247ydi (5:1135)
                                margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 0*fem, 0*fem),
                                padding: EdgeInsets.fromLTRB(60.15*fem, 2.5*fem, 0*fem, 4.5*fem),
                                child: Align(
                                  // plusuXN (5:1137)
                                  alignment: Alignment.centerRight,
                                  child: SizedBox(
                                    width: 15*fem,
                                    height: 15*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/plus-a5E.png',
                                      width: 15*fem,
                                      height: 15*fem,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // group252RVi (5:1119)
                    margin: EdgeInsets.fromLTRB(16*fem, 0*fem, 16.02*fem, 36*fem),
                    width: double.infinity,
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(44*fem),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // shippingmethodk2C (5:1120)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                          child: Text(
                            'SHIPPING METHOD',
                            style: SafeGoogleFont (
                              'Tenor Sans',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.1428571429*ffem/fem,
                              letterSpacing: 1*fem,
                              color: Color(0xff888888),
                            ),
                          ),
                        ),
                        Container(
                          // frame40Exx (5:1121)
                          padding: EdgeInsets.fromLTRB(20*fem, 13*fem, 23.8*fem, 13*fem),
                          width: double.infinity,
                          height: 48*fem,
                          decoration: BoxDecoration (
                            color: Color(0xfff8f8f8),
                            borderRadius: BorderRadius.circular(44*fem),
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // bbakerstmarylkAc (5:1122)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 109.33*fem, 0*fem),
                                child: Text(
                                  'Pickup at store',
                                  style: SafeGoogleFont (
                                    'Tenor Sans',
                                    fontSize: 16*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.375*ffem/fem,
                                    color: Color(0xff555555),
                                  ),
                                ),
                              ),
                              Container(
                                // group247fHa (5:1123)
                                height: double.infinity,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // bbakerstmarylzak (5:1124)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 26.25*fem, 0*fem),
                                      child: Text(
                                        'FREE',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Tenor Sans',
                                          fontSize: 14*ffem,
                                          fontWeight: FontWeight.w400,
                                          height: 1.5714285714*ffem/fem,
                                          color: Color(0xff555555),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // downW3J (5:1125)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 2.06*fem),
                                      width: 11.61*fem,
                                      height: 5.8*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/down.png',
                                        width: 11.61*fem,
                                        height: 5.8*fem,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // group253Rg4 (5:1138)
                    margin: EdgeInsets.fromLTRB(16*fem, 0*fem, 17*fem, 125.29*fem),
                    width: double.infinity,
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(44*fem),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // paymentmethodZXN (5:1139)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                          child: Text(
                            'PAYMENT METHOD',
                            style: SafeGoogleFont (
                              'Tenor Sans',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.1428571429*ffem/fem,
                              letterSpacing: 1*fem,
                              color: Color(0xff888888),
                            ),
                          ),
                        ),
                        Container(
                          // frame41gM6 (5:1140)
                          padding: EdgeInsets.fromLTRB(20*fem, 13*fem, 23.8*fem, 13*fem),
                          width: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0xfff8f8f8),
                            borderRadius: BorderRadius.circular(44*fem),
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // bbakerstmarylbDA (5:1141)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 107.6*fem, 0*fem),
                                child: Text(
                                  'select payment method',
                                  style: SafeGoogleFont (
                                    'Tenor Sans',
                                    fontSize: 16*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.375*ffem/fem,
                                    color: Color(0xff555555),
                                  ),
                                ),
                              ),
                              Container(
                                // group247KQ4 (5:1142)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0.06*fem),
                                width: 11.61*fem,
                                height: 5.8*fem,
                                child: Image.asset(
                                  'assets/page-1/images/group-247.png',
                                  width: 11.61*fem,
                                  height: 5.8*fem,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupbedw1ng (TywC3CNWroz3WDcAZTbeDW)
                    margin: EdgeInsets.fromLTRB(16*fem, 0*fem, 30*fem, 0*fem),
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // totalxC8 (5:1118)
                          margin: EdgeInsets.fromLTRB(0*fem, 0.37*fem, 195*fem, 0*fem),
                          child: Text(
                            'TOTAL',
                            style: SafeGoogleFont (
                              'Tenor Sans',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w400,
                              height: 2.4642857143*ffem/fem,
                              letterSpacing: 3*fem,
                              color: Color(0xff333333),
                            ),
                          ),
                        ),
                        Container(
                          // rs95051r (5:1145)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0.37*fem),
                          child: Text(
                            ' RS 950',
                            style: SafeGoogleFont (
                              'Tenor Sans',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w400,
                              height: 2.15625*ffem/fem,
                              letterSpacing: 3*fem,
                              color: Color(0xffdd8560),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            TextButton(
              // buttonP2Y (5:1144)
              onPressed: () {},
              style: TextButton.styleFrom (
                padding: EdgeInsets.zero,
              ),
              child: Container(
                padding: EdgeInsets.fromLTRB(108.48*fem, 16.91*fem, 106*fem, 13.09*fem),
                width: double.infinity,
                height: 56*fem,
                decoration: BoxDecoration (
                  color: Color(0xff000000),
                ),
                child: Container(
                  // content5RA (I5:1144;861:2997)
                  width: double.infinity,
                  height: double.infinity,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        // shoppingbagEYx (I5:1144;835:3097)
                        margin: EdgeInsets.fromLTRB(0*fem, 0.84*fem, 25.67*fem, 0*fem),
                        width: 15.86*fem,
                        height: 18.79*fem,
                        child: Image.asset(
                          'assets/page-1/images/shopping-bag-R8c.png',
                          width: 15.86*fem,
                          height: 18.79*fem,
                        ),
                      ),
                      Text(
                        // checkoutkXJ (I5:1144;835:3096)
                        'PLACE ORDER',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Tenor Sans',
                          fontSize: 16*ffem,
                          fontWeight: FontWeight.w400,
                          height: 1.625*ffem/fem,
                          letterSpacing: 0.16*fem,
                          color: Color(0xfffcfcfc),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}