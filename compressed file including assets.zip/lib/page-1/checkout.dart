import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // checkoutu6Q (5:1007)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // headere3z (5:1097)
              padding: EdgeInsets.fromLTRB(16.31*fem, 3*fem, 25*fem, 0*fem),
              width: double.infinity,
              height: 60*fem,
              decoration: BoxDecoration (
                color: Color(0xffe7eaef),
                gradient: LinearGradient (
                  begin: Alignment(-0, -1),
                  end: Alignment(-0.003, 0.517),
                  colors: <Color>[Color(0xffffd3c1), Color(0x00ffddd0)],
                  stops: <double>[0, 1],
                ),
                borderRadius: BorderRadius.only (
                  bottomRight: Radius.circular(20*fem),
                  bottomLeft: Radius.circular(20*fem),
                ),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // menu3M2 (5:1099)
                    margin: EdgeInsets.fromLTRB(0*fem, 6.51*fem, 68.31*fem, 0*fem),
                    width: 23.39*fem,
                    height: 14*fem,
                    child: Image.asset(
                      'assets/page-1/images/menu-62U.png',
                      width: 23.39*fem,
                      height: 14*fem,
                    ),
                  ),
                  Container(
                    // screenshot202310200150551whJ (5:1102)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 38*fem, 0*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 144*fem,
                        height: 66*fem,
                        child: Image.asset(
                          'assets/page-1/images/screenshot-2023-10-20-015055-1-Ze8.png',
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // searchDPv (5:1100)
                    margin: EdgeInsets.fromLTRB(0*fem, 9*fem, 20.97*fem, 0*fem),
                    width: 20*fem,
                    height: 20*fem,
                    child: Image.asset(
                      'assets/page-1/images/search-rL8.png',
                      width: 20*fem,
                      height: 20*fem,
                    ),
                  ),
                  Container(
                    // shoppingbagwKv (5:1101)
                    margin: EdgeInsets.fromLTRB(0*fem, 10.01*fem, 0*fem, 0*fem),
                    width: 19.03*fem,
                    height: 22.55*fem,
                    child: Image.asset(
                      'assets/page-1/images/shopping-bag-sPv.png',
                      width: 19.03*fem,
                      height: 22.55*fem,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupui7aqgC (TywAJq65ureTYjYX8oUi7a)
              padding: EdgeInsets.fromLTRB(10*fem, 33.75*fem, 16*fem, 22*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogrouphuyg9wn (Tyw94nKoSvUyKcsob9HUYg)
                    margin: EdgeInsets.fromLTRB(108.83*fem, 0*fem, 101.17*fem, 0.42*fem),
                    width: double.infinity,
                    height: 41.83*fem,
                    child: Stack(
                      children: [
                        Positioned(
                          // checkoutUjA (5:1009)
                          left: 0*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 139*fem,
                              height: 40*fem,
                              child: Text(
                                'CHECKOUT',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Tenor Sans',
                                  fontSize: 18*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 2.2222222222*ffem/fem,
                                  letterSpacing: 4*fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // wMr (5:1010)
                          left: 7.0207214355*fem,
                          top: 32.5759277344*fem,
                          child: Align(
                            child: SizedBox(
                              width: 124.96*fem,
                              height: 9.25*fem,
                              child: Image.asset(
                                'assets/page-1/images/.png',
                                width: 124.96*fem,
                                height: 9.25*fem,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupjoqr3Qt (Tyw9B7Ub1oErQzibkVjoqr)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3.6*fem, 19*fem),
                    padding: EdgeInsets.fromLTRB(1*fem, 5.73*fem, 0*fem, 0*fem),
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // rectangle325MgU (5:1641)
                          margin: EdgeInsets.fromLTRB(0*fem, 0.27*fem, 23.4*fem, 0*fem),
                          width: 110*fem,
                          height: 144*fem,
                          child: Image.asset(
                            'assets/page-1/images/rectangle-325-dck.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                        Container(
                          // frame27fSG (I5:1624;700:1476)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8.27*fem),
                          width: 211*fem,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // frame14nmn (I5:1624;700:1444)
                                width: double.infinity,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      // lamereiwua (I5:1624;700:1445)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 6*fem),
                                      constraints: BoxConstraints (
                                        maxWidth: 111*fem,
                                      ),
                                      child: Text(
                                        'MOSCHINO \nHANDBAG',
                                        style: SafeGoogleFont (
                                          'Tenor Sans',
                                          fontSize: 14*ffem,
                                          fontWeight: FontWeight.w400,
                                          height: 1.4285714286*ffem/fem,
                                          letterSpacing: 2*fem,
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                    ),
                                    Text(
                                      // recycleboucleknitcardiganpinkE (I5:1624;700:1446)
                                      'Brandnew 2021 model cv213 handbag',
                                      style: SafeGoogleFont (
                                        'Tenor Sans',
                                        fontSize: 12*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.5*ffem/fem,
                                        color: Color(0xff555555),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // autogroup9gueAXS (Tyw9NMerKkJ1WjL9Nx9gue)
                                padding: EdgeInsets.fromLTRB(0*fem, 12*fem, 0*fem, 0*fem),
                                width: double.infinity,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      // group212hnG (I5:1624;700:1475)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                      child: Row(
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Container(
                                            // autogroupz1s8r9N (Tyw9VwGZ9WH8WJMLPTz1S8)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 13.06*fem, 0*fem),
                                            width: 24*fem,
                                            height: 24*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/auto-group-z1s8.png',
                                              width: 24*fem,
                                              height: 24*fem,
                                            ),
                                          ),
                                          Container(
                                            // wwW (I5:1624;700:1474)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 11.94*fem, 0.46*fem),
                                            child: Text(
                                              '1',
                                              style: SafeGoogleFont (
                                                'Tenor Sans',
                                                fontSize: 14*ffem,
                                                fontWeight: FontWeight.w400,
                                                height: 1*ffem/fem,
                                                color: Color(0xff000000),
                                              ),
                                            ),
                                          ),
                                          Container(
                                            // autogroupzzysg8Q (Tyw9Zbq7dhMAcTwh1QZZyS)
                                            width: 24*fem,
                                            height: 24*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/auto-group-zzys.png',
                                              width: 24*fem,
                                              height: 24*fem,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Text(
                                      // PHi (I5:1624;700:1447)
                                      'Rs 300/day',
                                      style: SafeGoogleFont (
                                        'Tenor Sans',
                                        fontSize: 15*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.6*ffem/fem,
                                        color: Color(0xffdd8560),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // line22Xep (5:1028)
                    margin: EdgeInsets.fromLTRB(6*fem, 0*fem, 0*fem, 7.76*fem),
                    width: 343*fem,
                    height: 1*fem,
                    decoration: BoxDecoration (
                      color: Color(0x19000000),
                    ),
                  ),
                  Container(
                    // frame28G6c (5:1013)
                    margin: EdgeInsets.fromLTRB(23*fem, 0*fem, 11*fem, 4.24*fem),
                    padding: EdgeInsets.fromLTRB(11.5*fem, 14*fem, 158*fem, 14*fem),
                    width: double.infinity,
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(30*fem),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // voucherN9e (5:1014)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 11.5*fem, 0*fem),
                          width: 21*fem,
                          height: 14.4*fem,
                          child: Image.asset(
                            'assets/page-1/images/voucher.png',
                            width: 21*fem,
                            height: 14.4*fem,
                          ),
                        ),
                        Text(
                          // addpromocodeHXW (5:1015)
                          'Add promo code',
                          style: SafeGoogleFont (
                            'Tenor Sans',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.1428571429*ffem/fem,
                            color: Color(0xff333333),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupjz3ap1e (Tyw9s1VmwbvqckWNx8Jz3A)
                    margin: EdgeInsets.fromLTRB(6*fem, 0*fem, 0*fem, 16*fem),
                    padding: EdgeInsets.fromLTRB(17*fem, 0*fem, 11*fem, 0*fem),
                    width: 343*fem,
                    height: 44*fem,
                    child: TextButton(
                      // frame29XAx (5:1016)
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(14.8*fem, 10.48*fem, 10*fem, 10.48*fem),
                        width: double.infinity,
                        height: double.infinity,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(30*fem),
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // doortodoordeliveryDJg (5:1017)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0.96*fem, 0*fem),
                              width: 18.24*fem,
                              height: 23.04*fem,
                              child: Image.asset(
                                'assets/page-1/images/door-to-door-delivery-f4U.png',
                                width: 18.24*fem,
                                height: 23.04*fem,
                              ),
                            ),
                            Container(
                              // deliveryjH2 (5:1018)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 180*fem, 0*fem),
                              child: Text(
                                'Delivery',
                                style: SafeGoogleFont (
                                  'Tenor Sans',
                                  fontSize: 14*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.1428571429*ffem/fem,
                                  color: Color(0xff333333),
                                ),
                              ),
                            ),
                            Container(
                              // rs50p3a (5:1019)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                              child: Text(
                                '        RS50',
                                textAlign: TextAlign.right,
                                style: SafeGoogleFont (
                                  'Tenor Sans',
                                  fontSize: 14*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.1428571429*ffem/fem,
                                  color: Color(0xff555555),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // autogroupktps95r (TywA2AuBA5bvtAVGVyktPS)
                    margin: EdgeInsets.fromLTRB(6*fem, 0*fem, 0*fem, 217.73*fem),
                    padding: EdgeInsets.fromLTRB(16*fem, 0*fem, 12*fem, 0*fem),
                    width: 343*fem,
                    height: 44*fem,
                    child: Container(
                      // frame30eoJ (5:1020)
                      padding: EdgeInsets.fromLTRB(14.8*fem, 10.48*fem, 13.95*fem, 10.48*fem),
                      width: double.infinity,
                      height: double.infinity,
                      decoration: BoxDecoration (
                        borderRadius: BorderRadius.circular(30*fem),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // doortodoordeliveryMSp (5:1021)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0.96*fem, 0*fem),
                            width: 18.24*fem,
                            height: 23.04*fem,
                            child: Image.asset(
                              'assets/page-1/images/door-to-door-delivery.png',
                              width: 18.24*fem,
                              height: 23.04*fem,
                            ),
                          ),
                          Container(
                            // rentaldayssg4 (5:1022)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 178.05*fem, 0*fem),
                            child: Text(
                              ' Rental Days',
                              style: SafeGoogleFont (
                                'Tenor Sans',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.1428571429*ffem/fem,
                                color: Color(0xff333333),
                              ),
                            ),
                          ),
                          Container(
                            // bc4 (5:1023)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                            child: Text(
                              '3',
                              textAlign: TextAlign.right,
                              style: SafeGoogleFont (
                                'Tenor Sans',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.1428571429*ffem/fem,
                                color: Color(0xff555555),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Container(
                    // autogroup2omjXkc (TywA9fgghNyNHKZdax2omJ)
                    margin: EdgeInsets.fromLTRB(6*fem, 0*fem, 13*fem, 0*fem),
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // esttotalfrp (5:1025)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 146*fem, 0.27*fem),
                          child: Text(
                            'EST. TOTAL',
                            style: SafeGoogleFont (
                              'Tenor Sans',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w400,
                              height: 2.4642857143*ffem/fem,
                              letterSpacing: 3*fem,
                              color: Color(0xff333333),
                            ),
                          ),
                        ),
                        Container(
                          // rs950mur (5:1026)
                          margin: EdgeInsets.fromLTRB(0*fem, 0.27*fem, 0*fem, 0*fem),
                          child: Text(
                            ' RS 950',
                            style: SafeGoogleFont (
                              'Tenor Sans',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w400,
                              height: 2.15625*ffem/fem,
                              letterSpacing: 3*fem,
                              color: Color(0xffdd8560),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // buttonsT6 (5:1024)
              padding: EdgeInsets.fromLTRB(78.98*fem, 16.91*fem, 77.5*fem, 13.09*fem),
              width: double.infinity,
              height: 56*fem,
              decoration: BoxDecoration (
                color: Color(0xff000000),
              ),
              child: Container(
                // contentQ5e (I5:1024;861:2997)
                width: double.infinity,
                height: double.infinity,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // shoppingbagjNp (I5:1024;835:3097)
                      margin: EdgeInsets.fromLTRB(0*fem, 0.84*fem, 26.67*fem, 0*fem),
                      width: 15.86*fem,
                      height: 18.79*fem,
                      child: Image.asset(
                        'assets/page-1/images/shopping-bag-DwN.png',
                        width: 15.86*fem,
                        height: 18.79*fem,
                      ),
                    ),
                    Text(
                      // checkouteEt (I5:1024;835:3096)
                      'CHECKOUT TO RENT',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Tenor Sans',
                        fontSize: 16*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.625*ffem/fem,
                        letterSpacing: 0.16*fem,
                        color: Color(0xfffcfcfc),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}