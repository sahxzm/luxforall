import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // productdetaillayout2t3r (5:1415)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // headerQ2C (5:1649)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 9*fem),
              padding: EdgeInsets.fromLTRB(16.31*fem, 3*fem, 25*fem, 0*fem),
              width: double.infinity,
              height: 60*fem,
              decoration: BoxDecoration (
                color: Color(0xffe7eaef),
                gradient: LinearGradient (
                  begin: Alignment(-0, -1),
                  end: Alignment(-0.003, 0.517),
                  colors: <Color>[Color(0xffffd3c1), Color(0x00ffddd0)],
                  stops: <double>[0, 1],
                ),
                borderRadius: BorderRadius.only (
                  bottomRight: Radius.circular(20*fem),
                  bottomLeft: Radius.circular(20*fem),
                ),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // menuP92 (5:1651)
                    margin: EdgeInsets.fromLTRB(0*fem, 6.51*fem, 68.31*fem, 0*fem),
                    width: 23.39*fem,
                    height: 14*fem,
                    child: Image.asset(
                      'assets/page-1/images/menu-iDv.png',
                      width: 23.39*fem,
                      height: 14*fem,
                    ),
                  ),
                  Container(
                    // screenshot202310200150551gP2 (5:1654)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 38*fem, 0*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 144*fem,
                        height: 66*fem,
                        child: Image.asset(
                          'assets/page-1/images/screenshot-2023-10-20-015055-1-ACx.png',
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // searchw44 (5:1652)
                    margin: EdgeInsets.fromLTRB(0*fem, 9*fem, 20.97*fem, 0*fem),
                    width: 20*fem,
                    height: 20*fem,
                    child: Image.asset(
                      'assets/page-1/images/search-rAt.png',
                      width: 20*fem,
                      height: 20*fem,
                    ),
                  ),
                  Container(
                    // shoppingbag376 (5:1653)
                    margin: EdgeInsets.fromLTRB(0*fem, 10.01*fem, 0*fem, 0*fem),
                    width: 19.03*fem,
                    height: 22.55*fem,
                    child: Image.asset(
                      'assets/page-1/images/shopping-bag-big.png',
                      width: 19.03*fem,
                      height: 22.55*fem,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // frame61ABi (5:1674)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8.67*fem),
              width: double.infinity,
              height: 507*fem,
              child: Align(
                // rectangle325WFa (5:1675)
                alignment: Alignment.topLeft,
                child: SizedBox(
                  width: 380*fem,
                  height: 515*fem,
                  child: Image.asset(
                    'assets/page-1/images/rectangle-325.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
            Container(
              // frame52pGG (5:1463)
              margin: EdgeInsets.fromLTRB(14*fem, 0*fem, 0*fem, 77*fem),
              width: 425.82*fem,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    // group2618nk (5:1464)
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // moschinohandbagtG8 (5:1465)
                          margin: EdgeInsets.fromLTRB(0*fem, 2.85*fem, 158.48*fem, 0*fem),
                          child: Text(
                            'MOSCHINO HANDBAG',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Tenor Sans',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.17*ffem/fem,
                              letterSpacing: 4*fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                        Container(
                          // exportMfW (5:1466)
                          width: 11.33*fem,
                          height: 14*fem,
                          child: Image.asset(
                            'assets/page-1/images/export.png',
                            width: 11.33*fem,
                            height: 14*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 8*fem,
                  ),
                  Container(
                    // conditionbrandnew2021moschinob (5:1467)
                    width: double.infinity,
                    child: Text(
                      'CONDITION ; BRAND NEW 2021 MOSCHINO BAG',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Tenor Sans',
                        fontSize: 16*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.17*ffem/fem,
                        color: Color(0xff555555),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 8*fem,
                  ),
                  Container(
                    // rs300dayx9W (5:1468)
                    margin: EdgeInsets.fromLTRB(2*fem, 0*fem, 0*fem, 0*fem),
                    child: Text(
                      'RS 300/DAY',
                      style: SafeGoogleFont (
                        'Tenor Sans',
                        fontSize: 18*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.17*ffem/fem,
                        color: Color(0xffdd8560),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            TextButton(
              // buttonfpc (5:1454)
              onPressed: () {},
              style: TextButton.styleFrom (
                padding: EdgeInsets.zero,
              ),
              child: Container(
                padding: EdgeInsets.fromLTRB(0.9*fem, 10.08*fem, 35*fem, 5.92*fem),
                width: double.infinity,
                height: 56*fem,
                decoration: BoxDecoration (
                  color: Color(0xff000000),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // group206MSY (I5:1454;681:1225)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 140.1*fem, 0*fem),
                      padding: EdgeInsets.fromLTRB(17.6*fem, 7.83*fem, 14.59*fem, 8.17*fem),
                      width: 177*fem,
                      height: double.infinity,
                      child: Container(
                        // group18FH2 (I5:1454;681:1199)
                        width: double.infinity,
                        height: double.infinity,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // plusbbn (I5:1454;681:1204)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.81*fem, 2.26*fem),
                              width: 15*fem,
                              height: 15*fem,
                              child: Image.asset(
                                'assets/page-1/images/plus-k5n.png',
                                width: 15*fem,
                                height: 15*fem,
                              ),
                            ),
                            Text(
                              // addtobasketvPA (I5:1454;681:1200)
                              'ADD TO BASKET',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Tenor Sans',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.7142857143*ffem/fem,
                                letterSpacing: 0.14*fem,
                                color: Color(0xfffcfcfc),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Container(
                      // heartrGp (I5:1454;693:1203)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 2.06*fem),
                      width: 22*fem,
                      height: 19.49*fem,
                      child: Image.asset(
                        'assets/page-1/images/heart-vsa.png',
                        width: 22*fem,
                        height: 19.49*fem,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Container(
              // autogroupnnbzaic (TywHzwc5odkhPxTyf5NNBz)
              padding: EdgeInsets.fromLTRB(15.67*fem, 29.48*fem, 0*fem, 47*fem),
              width: double.infinity,
              height: 1834.48*fem,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // gallerygWk (5:1449)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 15.67*fem, 27.84*fem),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // galleryRDS (5:1450)
                          margin: EdgeInsets.fromLTRB(4.42*fem, 0*fem, 0*fem, 10.07*fem),
                          child: Text(
                            'GALLERY',
                            style: SafeGoogleFont (
                              'Tenor Sans',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.7142857143*ffem/fem,
                              letterSpacing: 0.14*fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                        Container(
                          // image16vfz (5:1451)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16.8*fem),
                          width: 343*fem,
                          height: 167.72*fem,
                          child: Image.asset(
                            'assets/page-1/images/image-16.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                        Container(
                          // image17TA8 (5:1452)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 15.31*fem),
                          width: 343*fem,
                          height: 343*fem,
                          child: Image.asset(
                            'assets/page-1/images/image-17.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                        Container(
                          // image18aVe (5:1453)
                          width: 343*fem,
                          height: 257.25*fem,
                          child: Image.asset(
                            'assets/page-1/images/image-18.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // servicetmE (5:1425)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 36.2*fem),
                    width: 386.87*fem,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // careXZJ (5:1436)
                          margin: EdgeInsets.fromLTRB(4.76*fem, 0*fem, 0*fem, 17.35*fem),
                          child: Text(
                            'CARE',
                            style: SafeGoogleFont (
                              'Tenor Sans',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.7142857143*ffem/fem,
                              letterSpacing: 0.14*fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                        Container(
                          // frame53zxg (5:1437)
                          margin: EdgeInsets.fromLTRB(2.33*fem, 0*fem, 0*fem, 32.28*fem),
                          width: 384.53*fem,
                          height: 43.81*fem,
                          child: Stack(
                            children: [
                              Positioned(
                                // autogroupr88yKk4 (TywKgyd4ojsAjt4VEVr88Y)
                                left: 34.5328369141*fem,
                                top: 0*fem,
                                child: Container(
                                  width: 301.39*fem,
                                  height: 24*fem,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // freeflatrateshippingrV6 (5:1438)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 124.47*fem, 0*fem),
                                        child: Text(
                                          'Free Flat Rate Shipping',
                                          style: SafeGoogleFont (
                                            'Tenor Sans',
                                            fontSize: 14*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.7142857143*ffem/fem,
                                            letterSpacing: 0.14*fem,
                                            color: Color(0xff000000),
                                          ),
                                        ),
                                      ),
                                      Opacity(
                                        // forwardMwe (5:1440)
                                        opacity: 0.5,
                                        child: Container(
                                          margin: EdgeInsets.fromLTRB(0*fem, 0.91*fem, 0*fem, 0*fem),
                                          width: 13.93*fem,
                                          height: 6.96*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/forward-wPN.png',
                                            width: 13.93*fem,
                                            height: 6.96*fem,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Positioned(
                                // estimatedtobedeliveredon091120 (5:1439)
                                left: 34.5328369141*fem,
                                top: 25.806640625*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 350*fem,
                                    height: 18*fem,
                                    child: Text(
                                      'Estimated to be delivered on \n09/11/2021 - 12/11/2021.\n',
                                      style: SafeGoogleFont (
                                        'Tenor Sans',
                                        fontSize: 14*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.2857142857*ffem/fem,
                                        color: Color(0xff555555),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // truck8qv (5:1441)
                                left: 0*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 24*fem,
                                    height: 24*fem,
                                    child: Opacity(
                                      opacity: 0.5,
                                      child: Image.asset(
                                        'assets/page-1/images/truck.png',
                                        width: 24*fem,
                                        height: 24*fem,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // frame54BZJ (5:1428)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 7.32*fem),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Opacity(
                                // tag8De (5:1430)
                                opacity: 0.5,
                                child: Container(
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 13.3*fem, 1.76*fem),
                                  width: 23.57*fem,
                                  height: 23.57*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/tag.png',
                                    width: 23.57*fem,
                                    height: 23.57*fem,
                                  ),
                                ),
                              ),
                              Container(
                                // codpolicydAQ (5:1429)
                                margin: EdgeInsets.fromLTRB(0*fem, 1.33*fem, 218.54*fem, 0*fem),
                                child: Text(
                                  'COD Policy',
                                  style: SafeGoogleFont (
                                    'Tenor Sans',
                                    fontSize: 12*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 2*ffem/fem,
                                    letterSpacing: 0.12*fem,
                                    color: Color(0xff000000),
                                  ),
                                ),
                              ),
                              Opacity(
                                // forwardKov (5:1431)
                                opacity: 0.5,
                                child: Container(
                                  margin: EdgeInsets.fromLTRB(0*fem, 2.3*fem, 0*fem, 0*fem),
                                  width: 13.93*fem,
                                  height: 6.96*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/forward-SPz.png',
                                    width: 13.93*fem,
                                    height: 6.96*fem,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // frame55NXJ (5:1432)
                          margin: EdgeInsets.fromLTRB(4.37*fem, 0*fem, 0*fem, 0*fem),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Opacity(
                                // refresh7Ut (5:1434)
                                opacity: 0.5,
                                child: Container(
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 12.75*fem, 0*fem),
                                  width: 19.74*fem,
                                  height: 16.67*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/refresh.png',
                                    width: 19.74*fem,
                                    height: 16.67*fem,
                                  ),
                                ),
                              ),
                              Container(
                                // returnpolicyp8Q (5:1433)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 208.54*fem, 0*fem),
                                child: Text(
                                  'Return Policy',
                                  style: SafeGoogleFont (
                                    'Tenor Sans',
                                    fontSize: 12*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 2*ffem/fem,
                                    letterSpacing: 0.12*fem,
                                    color: Color(0xff000000),
                                  ),
                                ),
                              ),
                              Opacity(
                                // forward8Pz (5:1435)
                                opacity: 0.5,
                                child: Container(
                                  margin: EdgeInsets.fromLTRB(0*fem, 0.96*fem, 0*fem, 0*fem),
                                  width: 13.93*fem,
                                  height: 6.96*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/forward-KHa.png',
                                    width: 13.93*fem,
                                    height: 6.96*fem,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // relatedproductR8C (5:1417)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16.67*fem, 0*fem),
                    width: 342*fem,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // titlevqe (5:1422)
                          margin: EdgeInsets.fromLTRB(36.17*fem, 0*fem, 41.83*fem, 30.69*fem),
                          width: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // youmayalsolikesVz (5:1423)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0.49*fem),
                                child: Text(
                                  'YOU MAY ALSO LIKE',
                                  style: SafeGoogleFont (
                                    'Tenor Sans',
                                    fontSize: 18*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 2.2222222222*ffem/fem,
                                    letterSpacing: 4*fem,
                                    color: Color(0xff000000),
                                  ),
                                ),
                              ),
                              Container(
                                // avC (5:1424)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 6*fem, 0*fem),
                                width: 124.96*fem,
                                height: 9.25*fem,
                                child: Image.asset(
                                  'assets/page-1/images/-FRi.png',
                                  width: 124.96*fem,
                                  height: 9.25*fem,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // autogroupoqbnuxU (TywJCwG6fiLzqQaxbRoqbN)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 19*fem),
                          width: double.infinity,
                          height: 285*fem,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // frame21ev4 (5:1418)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 12*fem, 0*fem),
                                width: 165*fem,
                                height: double.infinity,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // frame18Q8Y (I5:1418;671:985)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                      padding: EdgeInsets.fromLTRB(140.67*fem, 199.33*fem, 9.67*fem, 7.67*fem),
                                      width: double.infinity,
                                      height: 220*fem,
                                      decoration: BoxDecoration (
                                        image: DecorationImage (
                                          fit: BoxFit.cover,
                                          image: AssetImage (
                                            'assets/page-1/images/rectangle-344-bg-Zda.png',
                                          ),
                                        ),
                                      ),
                                      child: Align(
                                        // heartgbr (I5:1418;671:957)
                                        alignment: Alignment.bottomRight,
                                        child: SizedBox(
                                          width: 14.67*fem,
                                          height: 13*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/heart-bax.png',
                                            width: 14.67*fem,
                                            height: 13*fem,
                                          ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // frame15R3e (I5:1418;671:962)
                                      margin: EdgeInsets.fromLTRB(4*fem, 0*fem, 8*fem, 0*fem),
                                      width: double.infinity,
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            // frame14A1E (I5:1418;671:961)
                                            width: double.infinity,
                                            height: 33*fem,
                                            child: Stack(
                                              children: [
                                                Positioned(
                                                  // wnGpx (I5:1418;671:960)
                                                  left: 0*fem,
                                                  top: 0*fem,
                                                  child: Align(
                                                    child: SizedBox(
                                                      width: 38*fem,
                                                      height: 18*fem,
                                                      child: Text(
                                                        '21WN ',
                                                        style: SafeGoogleFont (
                                                          'Tenor Sans',
                                                          fontSize: 12*ffem,
                                                          fontWeight: FontWeight.w400,
                                                          height: 1.5*ffem/fem,
                                                          color: Color(0xff000000),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  // reversibleangoracardiganY1n (I5:1418;671:946)
                                                  left: 0*fem,
                                                  top: 15*fem,
                                                  child: Align(
                                                    child: SizedBox(
                                                      width: 153*fem,
                                                      height: 18*fem,
                                                      child: Text(
                                                        'reversible angora cardigan',
                                                        style: SafeGoogleFont (
                                                          'Tenor Sans',
                                                          fontSize: 12*ffem,
                                                          fontWeight: FontWeight.w400,
                                                          height: 1.5*ffem/fem,
                                                          color: Color(0xff555555),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Text(
                                            // 1vx (I5:1418;671:947)
                                            '\$120',
                                            style: SafeGoogleFont (
                                              'Tenor Sans',
                                              fontSize: 15*ffem,
                                              fontWeight: FontWeight.w400,
                                              height: 1.6*ffem/fem,
                                              color: Color(0xffdd8560),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // frame22ZSg (5:1421)
                                width: 165*fem,
                                height: double.infinity,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // frame18WMv (I5:1421;671:985)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                      padding: EdgeInsets.fromLTRB(140.67*fem, 199.33*fem, 9.67*fem, 7.67*fem),
                                      width: double.infinity,
                                      height: 220*fem,
                                      decoration: BoxDecoration (
                                        image: DecorationImage (
                                          fit: BoxFit.cover,
                                          image: AssetImage (
                                            'assets/page-1/images/rectangle-344-bg-EuN.png',
                                          ),
                                        ),
                                      ),
                                      child: Align(
                                        // heartDGL (I5:1421;671:957)
                                        alignment: Alignment.bottomRight,
                                        child: SizedBox(
                                          width: 14.67*fem,
                                          height: 13*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/heart-5cc.png',
                                            width: 14.67*fem,
                                            height: 13*fem,
                                          ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // frame159fn (I5:1421;671:962)
                                      margin: EdgeInsets.fromLTRB(4*fem, 0*fem, 8*fem, 0*fem),
                                      width: double.infinity,
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            // frame14Ex8 (I5:1421;671:961)
                                            width: double.infinity,
                                            height: 33*fem,
                                            child: Stack(
                                              children: [
                                                Positioned(
                                                  // wnzwJ (I5:1421;671:960)
                                                  left: 0*fem,
                                                  top: 0*fem,
                                                  child: Align(
                                                    child: SizedBox(
                                                      width: 38*fem,
                                                      height: 18*fem,
                                                      child: Text(
                                                        '21WN ',
                                                        style: SafeGoogleFont (
                                                          'Tenor Sans',
                                                          fontSize: 12*ffem,
                                                          fontWeight: FontWeight.w400,
                                                          height: 1.5*ffem/fem,
                                                          color: Color(0xff000000),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  // reversibleangoracardigang3S (I5:1421;671:946)
                                                  left: 0*fem,
                                                  top: 15*fem,
                                                  child: Align(
                                                    child: SizedBox(
                                                      width: 153*fem,
                                                      height: 18*fem,
                                                      child: Text(
                                                        'reversible angora cardigan',
                                                        style: SafeGoogleFont (
                                                          'Tenor Sans',
                                                          fontSize: 12*ffem,
                                                          fontWeight: FontWeight.w400,
                                                          height: 1.5*ffem/fem,
                                                          color: Color(0xff555555),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Text(
                                            // yoE (I5:1421;671:947)
                                            '\$120',
                                            style: SafeGoogleFont (
                                              'Tenor Sans',
                                              fontSize: 15*ffem,
                                              fontWeight: FontWeight.w400,
                                              height: 1.6*ffem/fem,
                                              color: Color(0xffdd8560),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // autogroupr2vkKs6 (TywJYBD3DiTgtmwpr7r2vk)
                          width: double.infinity,
                          height: 285*fem,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // frame2355a (5:1419)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 12*fem, 0*fem),
                                width: 165*fem,
                                height: double.infinity,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // frame18nkg (I5:1419;671:985)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                      padding: EdgeInsets.fromLTRB(140.67*fem, 199.33*fem, 9.67*fem, 7.67*fem),
                                      width: double.infinity,
                                      height: 220*fem,
                                      decoration: BoxDecoration (
                                        image: DecorationImage (
                                          fit: BoxFit.cover,
                                          image: AssetImage (
                                            'assets/page-1/images/rectangle-344-bg.png',
                                          ),
                                        ),
                                      ),
                                      child: Align(
                                        // heartWAt (I5:1419;671:957)
                                        alignment: Alignment.bottomRight,
                                        child: SizedBox(
                                          width: 14.67*fem,
                                          height: 13*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/heart.png',
                                            width: 14.67*fem,
                                            height: 13*fem,
                                          ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // frame15pBa (I5:1419;671:962)
                                      margin: EdgeInsets.fromLTRB(4*fem, 0*fem, 8*fem, 0*fem),
                                      width: double.infinity,
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            // frame14MxC (I5:1419;671:961)
                                            width: double.infinity,
                                            height: 33*fem,
                                            child: Stack(
                                              children: [
                                                Positioned(
                                                  // wnJMe (I5:1419;671:960)
                                                  left: 0*fem,
                                                  top: 0*fem,
                                                  child: Align(
                                                    child: SizedBox(
                                                      width: 38*fem,
                                                      height: 18*fem,
                                                      child: Text(
                                                        '21WN ',
                                                        style: SafeGoogleFont (
                                                          'Tenor Sans',
                                                          fontSize: 12*ffem,
                                                          fontWeight: FontWeight.w400,
                                                          height: 1.5*ffem/fem,
                                                          color: Color(0xff000000),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  // reversibleangoracardiganDDi (I5:1419;671:946)
                                                  left: 0*fem,
                                                  top: 15*fem,
                                                  child: Align(
                                                    child: SizedBox(
                                                      width: 153*fem,
                                                      height: 18*fem,
                                                      child: Text(
                                                        'reversible angora cardigan',
                                                        style: SafeGoogleFont (
                                                          'Tenor Sans',
                                                          fontSize: 12*ffem,
                                                          fontWeight: FontWeight.w400,
                                                          height: 1.5*ffem/fem,
                                                          color: Color(0xff555555),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Text(
                                            // iAU (I5:1419;671:947)
                                            '\$120',
                                            style: SafeGoogleFont (
                                              'Tenor Sans',
                                              fontSize: 15*ffem,
                                              fontWeight: FontWeight.w400,
                                              height: 1.6*ffem/fem,
                                              color: Color(0xffdd8560),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // frame24Ttk (5:1420)
                                width: 165*fem,
                                height: double.infinity,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // frame18Dsv (I5:1420;671:985)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                      padding: EdgeInsets.fromLTRB(140.67*fem, 199.33*fem, 9.67*fem, 7.67*fem),
                                      width: double.infinity,
                                      height: 220*fem,
                                      decoration: BoxDecoration (
                                        image: DecorationImage (
                                          fit: BoxFit.cover,
                                          image: AssetImage (
                                            'assets/page-1/images/rectangle-344-bg-H1z.png',
                                          ),
                                        ),
                                      ),
                                      child: Align(
                                        // heartvGY (I5:1420;671:957)
                                        alignment: Alignment.bottomRight,
                                        child: SizedBox(
                                          width: 14.67*fem,
                                          height: 13*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/heart-fzx.png',
                                            width: 14.67*fem,
                                            height: 13*fem,
                                          ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // frame154Nk (I5:1420;671:962)
                                      margin: EdgeInsets.fromLTRB(4*fem, 0*fem, 8*fem, 0*fem),
                                      width: double.infinity,
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            // frame14Czk (I5:1420;671:961)
                                            width: double.infinity,
                                            height: 33*fem,
                                            child: Stack(
                                              children: [
                                                Positioned(
                                                  // wnpFS (I5:1420;671:960)
                                                  left: 0*fem,
                                                  top: 0*fem,
                                                  child: Align(
                                                    child: SizedBox(
                                                      width: 38*fem,
                                                      height: 18*fem,
                                                      child: Text(
                                                        '21WN ',
                                                        style: SafeGoogleFont (
                                                          'Tenor Sans',
                                                          fontSize: 12*ffem,
                                                          fontWeight: FontWeight.w400,
                                                          height: 1.5*ffem/fem,
                                                          color: Color(0xff000000),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  // reversibleangoracardiganirc (I5:1420;671:946)
                                                  left: 0*fem,
                                                  top: 15*fem,
                                                  child: Align(
                                                    child: SizedBox(
                                                      width: 153*fem,
                                                      height: 18*fem,
                                                      child: Text(
                                                        'reversible angora cardigan',
                                                        style: SafeGoogleFont (
                                                          'Tenor Sans',
                                                          fontSize: 12*ffem,
                                                          fontWeight: FontWeight.w400,
                                                          height: 1.5*ffem/fem,
                                                          color: Color(0xff555555),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Text(
                                            // mpt (I5:1420;671:947)
                                            '\$120',
                                            style: SafeGoogleFont (
                                              'Tenor Sans',
                                              fontSize: 15*ffem,
                                              fontWeight: FontWeight.w400,
                                              height: 1.6*ffem/fem,
                                              color: Color(0xffdd8560),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // footerX3N (5:1416)
              padding: EdgeInsets.fromLTRB(0*fem, 23.78*fem, 0*fem, 0*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // group293Gc (I5:1416;639:716)
                    margin: EdgeInsets.fromLTRB(151.5*fem, 0*fem, 150.5*fem, 24*fem),
                    padding: EdgeInsets.fromLTRB(1.6*fem, 2.4*fem, 1.6*fem, 2.4*fem),
                    width: double.infinity,
                    height: 24*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // twitter9aY (I5:1416;560:875)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 49*fem, 0*fem),
                          width: 20.8*fem,
                          height: 16.9*fem,
                          child: Image.asset(
                            'assets/page-1/images/twitter-nUp.png',
                            width: 20.8*fem,
                            height: 16.9*fem,
                          ),
                        ),
                        Container(
                          // instagramSpY (I5:1416;560:877)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 49*fem, 0*fem),
                          width: 19.2*fem,
                          height: 19.2*fem,
                          child: Image.asset(
                            'assets/page-1/images/instagram-iCp.png',
                            width: 19.2*fem,
                            height: 19.2*fem,
                          ),
                        ),
                        Container(
                          // youtubeaA4 (I5:1416;560:881)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                          width: 20.8*fem,
                          height: 17.6*fem,
                          child: Image.asset(
                            'assets/page-1/images/youtube-EPA.png',
                            width: 20.8*fem,
                            height: 17.6*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // UWL (I5:1416;585:713)
                    margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 18.73*fem),
                    width: 124.96*fem,
                    height: 9.25*fem,
                    child: Image.asset(
                      'assets/page-1/images/-JWt.png',
                      width: 124.96*fem,
                      height: 9.25*fem,
                    ),
                  ),
                  Container(
                    // supportopenuidesign60825876080 (I5:1416;560:899)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 76.76*fem),
                    child: Text(
                      'support@openui.design\n+60 825 876\n08:00 - 22:00 - Everyday\n',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Tenor Sans',
                        fontSize: 16*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.8399999142*ffem/fem,
                        color: Color(0xff333333),
                      ),
                    ),
                  ),
                  Container(
                    // e3S (I5:1416;651:912)
                    margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 32*fem),
                    width: 124.96*fem,
                    height: 9.25*fem,
                    child: Image.asset(
                      'assets/page-1/images/-xT2.png',
                      width: 124.96*fem,
                      height: 9.25*fem,
                    ),
                  ),
                  Container(
                    // autogrouptktvNVE (TywL2Da1MjyroFRMVBtKTv)
                    margin: EdgeInsets.fromLTRB(103*fem, 0*fem, 114*fem, 22.97*fem),
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Text(
                          // aboutWLY (I5:1416;560:885)
                          'About',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Tenor Sans',
                            fontSize: 16*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.5*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                        SizedBox(
                          width: 52*fem,
                        ),
                        Text(
                          // contactceU (I5:1416;560:886)
                          'Contact',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Tenor Sans',
                            fontSize: 16*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.5*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                        SizedBox(
                          width: 52*fem,
                        ),
                        Text(
                          // blogkkg (I5:1416;560:887)
                          'Blog',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Tenor Sans',
                            fontSize: 16*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.5*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupbqhaJnC (TywL9dXKcajcbzYtecbqhA)
                    margin: EdgeInsets.fromLTRB(45*fem, 0*fem, 44*fem, 0*fem),
                    width: double.infinity,
                    height: 45.25*fem,
                    decoration: BoxDecoration (
                      color: Color(0x19c4c4c4),
                    ),
                    child: Center(
                      child: Text(
                        'Copyright© OpenUI All Rights Reserved.',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Tenor Sans',
                          fontSize: 12*ffem,
                          fontWeight: FontWeight.w400,
                          height: 1.5849998792*ffem/fem,
                          color: Color(0xff555555),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}