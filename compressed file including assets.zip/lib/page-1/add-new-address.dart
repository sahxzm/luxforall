import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // addnewaddressC2U (5:1194)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroupylt2wEx (TywEA41URfRwfAtuF2YLT2)
              padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 246.44*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // headerNLG (5:1266)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 35.75*fem),
                    padding: EdgeInsets.fromLTRB(16.31*fem, 3*fem, 25*fem, 0*fem),
                    width: double.infinity,
                    height: 60*fem,
                    decoration: BoxDecoration (
                      color: Color(0xffe7eaef),
                      gradient: LinearGradient (
                        begin: Alignment(-0, -1),
                        end: Alignment(-0.003, 0.517),
                        colors: <Color>[Color(0xffffd3c1), Color(0x00ffddd0)],
                        stops: <double>[0, 1],
                      ),
                      borderRadius: BorderRadius.only (
                        bottomRight: Radius.circular(20*fem),
                        bottomLeft: Radius.circular(20*fem),
                      ),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // menuMhz (5:1268)
                          margin: EdgeInsets.fromLTRB(0*fem, 6.51*fem, 68.31*fem, 0*fem),
                          width: 23.39*fem,
                          height: 14*fem,
                          child: Image.asset(
                            'assets/page-1/images/menu-SH6.png',
                            width: 23.39*fem,
                            height: 14*fem,
                          ),
                        ),
                        Container(
                          // screenshot202310200150551GKA (5:1271)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 38*fem, 0*fem),
                          child: TextButton(
                            onPressed: () {},
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Container(
                              width: 144*fem,
                              height: 66*fem,
                              child: Image.asset(
                                'assets/page-1/images/screenshot-2023-10-20-015055-1-7bn.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                        Container(
                          // searchMbW (5:1269)
                          margin: EdgeInsets.fromLTRB(0*fem, 9*fem, 20.97*fem, 0*fem),
                          width: 20*fem,
                          height: 20*fem,
                          child: Image.asset(
                            'assets/page-1/images/search-E1W.png',
                            width: 20*fem,
                            height: 20*fem,
                          ),
                        ),
                        Container(
                          // shoppingbag3z8 (5:1270)
                          margin: EdgeInsets.fromLTRB(0*fem, 10.01*fem, 0*fem, 0*fem),
                          width: 19.03*fem,
                          height: 22.55*fem,
                          child: Image.asset(
                            'assets/page-1/images/shopping-bag-f52.png',
                            width: 19.03*fem,
                            height: 22.55*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupspzuNFi (TywE1PbEuwSwxEayESSpzU)
                    margin: EdgeInsets.fromLTRB(40.33*fem, 0*fem, 38.67*fem, 26.42*fem),
                    width: double.infinity,
                    height: 41.83*fem,
                    child: Stack(
                      children: [
                        Positioned(
                          // addshippingadressVbE (5:1196)
                          left: 0*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 296*fem,
                              height: 40*fem,
                              child: Text(
                                'ADD SHIPPING ADRESS',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Tenor Sans',
                                  fontSize: 18*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 2.2222222222*ffem/fem,
                                  letterSpacing: 4*fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // AxG (5:1197)
                          left: 85.5204772949*fem,
                          top: 32.5759277344*fem,
                          child: Align(
                            child: SizedBox(
                              width: 124.96*fem,
                              height: 9.25*fem,
                              child: Image.asset(
                                'assets/page-1/images/-kmv.png',
                                width: 124.96*fem,
                                height: 9.25*fem,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // group248TwN (5:1198)
                    margin: EdgeInsets.fromLTRB(16*fem, 0*fem, 17*fem, 20.56*fem),
                    width: double.infinity,
                    height: 50*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // inputAqn (5:1205)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 12.31*fem, 0*fem),
                          padding: EdgeInsets.fromLTRB(0*fem, 15*fem, 0*fem, 0*fem),
                          width: 165.69*fem,
                          height: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                // text5hr (5:1208)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 15.97*fem),
                                child: Text(
                                  'First name',
                                  style: SafeGoogleFont (
                                    'Tenor Sans',
                                    fontSize: 15*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.17*ffem/fem,
                                    color: Color(0xff979797),
                                  ),
                                ),
                              ),
                              Container(
                                // lineBF6 (5:1207)
                                width: double.infinity,
                                height: 1.07*fem,
                                decoration: BoxDecoration (
                                  color: Color(0xffd3d3d3),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // inputLNt (5:1200)
                          padding: EdgeInsets.fromLTRB(0*fem, 14.56*fem, 0*fem, 0.41*fem),
                          width: 164*fem,
                          height: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                // text4Zn (5:1203)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 15.97*fem),
                                child: Text(
                                  'Last name',
                                  style: SafeGoogleFont (
                                    'Tenor Sans',
                                    fontSize: 15*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.17*ffem/fem,
                                    color: Color(0xff979797),
                                  ),
                                ),
                              ),
                              Container(
                                // linenEt (5:1202)
                                width: 165.32*fem,
                                height: 1.07*fem,
                                decoration: BoxDecoration (
                                  color: Color(0xffd3d3d3),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // inputieL (5:1221)
                    margin: EdgeInsets.fromLTRB(16*fem, 0*fem, 15.68*fem, 21*fem),
                    padding: EdgeInsets.fromLTRB(0*fem, 15*fem, 0*fem, 0*fem),
                    width: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // text3wW (5:1224)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                          child: Text(
                            'Adress',
                            style: SafeGoogleFont (
                              'Tenor Sans',
                              fontSize: 15*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.17*ffem/fem,
                              color: Color(0xff979797),
                            ),
                          ),
                        ),
                        Container(
                          // lineNit (5:1223)
                          width: 341.66*fem,
                          height: 1*fem,
                          decoration: BoxDecoration (
                            color: Color(0xffd3d3d3),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // inputjZS (5:1226)
                    margin: EdgeInsets.fromLTRB(16*fem, 0*fem, 17.34*fem, 20.44*fem),
                    padding: EdgeInsets.fromLTRB(0*fem, 15*fem, 0*fem, 0*fem),
                    width: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // textEWC (5:1229)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                          child: Text(
                            'City',
                            style: SafeGoogleFont (
                              'Tenor Sans',
                              fontSize: 15*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.17*ffem/fem,
                              color: Color(0xff979797),
                            ),
                          ),
                        ),
                        Container(
                          // linemW8 (5:1228)
                          width: double.infinity,
                          height: 1*fem,
                          decoration: BoxDecoration (
                            color: Color(0xffd3d3d3),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // group249vtp (5:1209)
                    margin: EdgeInsets.fromLTRB(16*fem, 0*fem, 17*fem, 20.56*fem),
                    width: double.infinity,
                    height: 50*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // input3Te (5:1216)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 12.31*fem, 0*fem),
                          padding: EdgeInsets.fromLTRB(0*fem, 15*fem, 0*fem, 0*fem),
                          width: 165.69*fem,
                          height: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                // textZB6 (5:1219)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 15.97*fem),
                                child: Text(
                                  'State',
                                  style: SafeGoogleFont (
                                    'Tenor Sans',
                                    fontSize: 15*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.17*ffem/fem,
                                    color: Color(0xff979797),
                                  ),
                                ),
                              ),
                              Container(
                                // linesSg (5:1218)
                                width: double.infinity,
                                height: 1.07*fem,
                                decoration: BoxDecoration (
                                  color: Color(0xffd3d3d3),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // inputdRr (5:1211)
                          padding: EdgeInsets.fromLTRB(0*fem, 14.56*fem, 0*fem, 0.41*fem),
                          width: 164*fem,
                          height: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                // textARn (5:1214)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 15.97*fem),
                                child: Text(
                                  'ZIP code',
                                  style: SafeGoogleFont (
                                    'Tenor Sans',
                                    fontSize: 15*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.17*ffem/fem,
                                    color: Color(0xff979797),
                                  ),
                                ),
                              ),
                              Container(
                                // lineVix (5:1213)
                                width: 165.32*fem,
                                height: 1.07*fem,
                                decoration: BoxDecoration (
                                  color: Color(0xffd3d3d3),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // inputrJc (5:1231)
                    margin: EdgeInsets.fromLTRB(16*fem, 0*fem, 17.34*fem, 0*fem),
                    padding: EdgeInsets.fromLTRB(0*fem, 15*fem, 0*fem, 0*fem),
                    width: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // textYhE (5:1234)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                          child: Text(
                            'Phone number',
                            style: SafeGoogleFont (
                              'Tenor Sans',
                              fontSize: 15*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.17*ffem/fem,
                              color: Color(0xff979797),
                            ),
                          ),
                        ),
                        Container(
                          // linerT2 (5:1233)
                          width: double.infinity,
                          height: 1*fem,
                          decoration: BoxDecoration (
                            color: Color(0xffd3d3d3),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            TextButton(
              // buttonch6 (5:1235)
              onPressed: () {},
              style: TextButton.styleFrom (
                padding: EdgeInsets.zero,
              ),
              child: Container(
                padding: EdgeInsets.fromLTRB(124*fem, 16.91*fem, 121.5*fem, 13.09*fem),
                width: double.infinity,
                height: 56*fem,
                decoration: BoxDecoration (
                  color: Color(0xff000000),
                ),
                child: Container(
                  // content8vL (I5:1235;861:2997)
                  width: double.infinity,
                  height: double.infinity,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        // plusuAQ (I5:1235;835:3097)
                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 26.5*fem, 0*fem),
                        width: 15*fem,
                        height: 15*fem,
                        child: Image.asset(
                          'assets/page-1/images/plus-6hN.png',
                          width: 15*fem,
                          height: 15*fem,
                        ),
                      ),
                      Text(
                        // checkoutReY (I5:1235;835:3096)
                        'ADD NOW',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Tenor Sans',
                          fontSize: 16*ffem,
                          fontWeight: FontWeight.w400,
                          height: 1.625*ffem/fem,
                          letterSpacing: 0.16*fem,
                          color: Color(0xfffcfcfc),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}