import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // bloggridviewT9A (5:796)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              // headerwa8 (5:822)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 29.49*fem),
              padding: EdgeInsets.fromLTRB(16.31*fem, 3*fem, 25*fem, 0*fem),
              width: double.infinity,
              height: 60*fem,
              decoration: BoxDecoration (
                color: Color(0xffe7eaef),
                gradient: LinearGradient (
                  begin: Alignment(-0, -1),
                  end: Alignment(-0.003, 0.517),
                  colors: <Color>[Color(0xffffd3c1), Color(0x00ffddd0)],
                  stops: <double>[0, 1],
                ),
                borderRadius: BorderRadius.only (
                  bottomRight: Radius.circular(20*fem),
                  bottomLeft: Radius.circular(20*fem),
                ),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // menuss6 (5:824)
                    margin: EdgeInsets.fromLTRB(0*fem, 6.51*fem, 68.31*fem, 0*fem),
                    width: 23.39*fem,
                    height: 14*fem,
                    child: Image.asset(
                      'assets/page-1/images/menu.png',
                      width: 23.39*fem,
                      height: 14*fem,
                    ),
                  ),
                  Container(
                    // screenshot202310200150551nUG (5:827)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 38*fem, 0*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 144*fem,
                        height: 66*fem,
                        child: Image.asset(
                          'assets/page-1/images/screenshot-2023-10-20-015055-1.png',
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // searchg3r (5:825)
                    margin: EdgeInsets.fromLTRB(0*fem, 9*fem, 20.97*fem, 0*fem),
                    width: 20*fem,
                    height: 20*fem,
                    child: Image.asset(
                      'assets/page-1/images/search-HsW.png',
                      width: 20*fem,
                      height: 20*fem,
                    ),
                  ),
                  Container(
                    // shoppingbagk3i (5:826)
                    margin: EdgeInsets.fromLTRB(0*fem, 10.01*fem, 0*fem, 0*fem),
                    width: 19.03*fem,
                    height: 22.55*fem,
                    child: Image.asset(
                      'assets/page-1/images/shopping-bag.png',
                      width: 19.03*fem,
                      height: 22.55*fem,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // titleFmA (5:797)
              margin: EdgeInsets.fromLTRB(20*fem, 0*fem, 125.19*fem, 27.68*fem),
              width: double.infinity,
              height: 41.83*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // iconarrowleftaYY (5:1667)
                    margin: EdgeInsets.fromLTRB(0*fem, 5.18*fem, 89.85*fem, 0*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 15*fem,
                        height: 14*fem,
                        child: Image.asset(
                          'assets/page-1/images/icon-arrow-left.png',
                          width: 15*fem,
                          height: 14*fem,
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // autogroupnvk44Cp (Tyw4pKa8m642fzntv7NVk4)
                    width: 124.96*fem,
                    height: double.infinity,
                    child: Stack(
                      children: [
                        Positioned(
                          // blog1Nx (5:798)
                          left: 27.4792785645*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 70*fem,
                              height: 40*fem,
                              child: Text(
                                'BLOG',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Tenor Sans',
                                  fontSize: 18*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 2.2222222222*ffem/fem,
                                  letterSpacing: 4*fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // fiQ (5:799)
                          left: 0*fem,
                          top: 32.5759277344*fem,
                          child: Align(
                            child: SizedBox(
                              width: 124.96*fem,
                              height: 9.25*fem,
                              child: Image.asset(
                                'assets/page-1/images/-82k.png',
                                width: 124.96*fem,
                                height: 9.25*fem,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // tagb6G (5:800)
              padding: EdgeInsets.fromLTRB(16*fem, 0*fem, 0*fem, 0*fem),
              width: double.infinity,
              height: 32*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // tagK2G (5:801)
                    width: 73*fem,
                    height: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xfff8f8f8),
                      borderRadius: BorderRadius.circular(30*fem),
                    ),
                    child: Center(
                      child: Text(
                        'Fashion',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Tenor Sans',
                          fontSize: 14*ffem,
                          fontWeight: FontWeight.w400,
                          height: 1.1428571429*ffem/fem,
                          letterSpacing: 0.14*fem,
                          color: Color(0xff333333),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    width: 12*fem,
                  ),
                  Container(
                    // frame5KgU (5:802)
                    width: 64*fem,
                    height: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xfff8f8f8),
                      borderRadius: BorderRadius.circular(30*fem),
                    ),
                    child: Center(
                      child: Text(
                        'Promo',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Tenor Sans',
                          fontSize: 14*ffem,
                          fontWeight: FontWeight.w400,
                          height: 1.1428571429*ffem/fem,
                          letterSpacing: 0.14*fem,
                          color: Color(0xff333333),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    width: 12*fem,
                  ),
                  Container(
                    // frame6PRS (5:803)
                    width: 61*fem,
                    height: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xfff8f8f8),
                      borderRadius: BorderRadius.circular(30*fem),
                    ),
                    child: Center(
                      child: Text(
                        'Policy',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Tenor Sans',
                          fontSize: 14*ffem,
                          fontWeight: FontWeight.w400,
                          height: 1.1428571429*ffem/fem,
                          letterSpacing: 0.14*fem,
                          color: Color(0xff333333),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    width: 12*fem,
                  ),
                  Container(
                    // frame75p4 (5:804)
                    width: 88*fem,
                    height: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xfff8f8f8),
                      borderRadius: BorderRadius.circular(30*fem),
                    ),
                    child: Center(
                      child: Text(
                        'Lookbook',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Tenor Sans',
                          fontSize: 14*ffem,
                          fontWeight: FontWeight.w400,
                          height: 1.1428571429*ffem/fem,
                          letterSpacing: 0.14*fem,
                          color: Color(0xff333333),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    width: 12*fem,
                  ),
                  Container(
                    // frame8Aac (5:805)
                    width: 49*fem,
                    height: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xfff8f8f8),
                      borderRadius: BorderRadius.circular(30*fem),
                    ),
                    child: Center(
                      child: Text(
                        'Sale',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Tenor Sans',
                          fontSize: 14*ffem,
                          fontWeight: FontWeight.w400,
                          height: 1.1428571429*ffem/fem,
                          letterSpacing: 0.14*fem,
                          color: Color(0xff333333),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupasxaUbJ (Tyw2K4Qqro7VuzDtuBASXa)
              padding: EdgeInsets.fromLTRB(16*fem, 32*fem, 16*fem, 34*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // frame43zZe (5:806)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 30.31*fem),
                    width: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // postXpU (5:807)
                          width: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // autogroupmtxuVmJ (Tyw2bYwN3evfPjPVgumTxU)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 7.67*fem),
                                padding: EdgeInsets.fromLTRB(0*fem, 12.92*fem, 0*fem, 0.29*fem),
                                width: double.infinity,
                                decoration: BoxDecoration (
                                  image: DecorationImage (
                                    image: AssetImage (
                                      'assets/page-1/images/rectangle-434-bg-LFS.png',
                                    ),
                                  ),
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  children: [
                                    Container(
                                      // bookmarkP5z (5:815)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 11*fem, 86.42*fem),
                                      width: 12*fem,
                                      height: 13.76*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/bookmark-Wcx.png',
                                        width: 12*fem,
                                        height: 13.76*fem,
                                      ),
                                    ),
                                    Container(
                                      // autogroupk1djenc (Tyw2hJGndKNmLDcWPTK1DJ)
                                      padding: EdgeInsets.fromLTRB(14*fem, 33.1*fem, 27*fem, 13.5*fem),
                                      width: double.infinity,
                                      height: 86.61*fem,
                                      decoration: BoxDecoration (
                                        gradient: LinearGradient (
                                          begin: Alignment(-0.177, 1),
                                          end: Alignment(-0.177, -0.979),
                                          colors: <Color>[Color(0xff111111), Color(0xfc111111), Color(0xf5111111), Color(0xea111111), Color(0xd9111111), Color(0xc3111111), Color(0xaa111111), Color(0x8e111111), Color(0x70111111), Color(0x54111111), Color(0x3b111111), Color(0x25111111), Color(0x14111111), Color(0x09111111), Color(0x02111111), Color(0x00111111)],
                                          stops: <double>[0, 0.067, 0.133, 0.2, 0.267, 0.333, 0.4, 0.467, 0.533, 0.6, 0.667, 0.733, 0.8, 0.867, 0.933, 1],
                                        ),
                                      ),
                                      child: Center(
                                        // styleguidethebiggestfalltrends (5:810)
                                        child: SizedBox(
                                          child: Container(
                                            constraints: BoxConstraints (
                                              maxWidth: 302*fem,
                                            ),
                                            child: Text(
                                              '2023 STYLE GUIDE: THE BIGGEST \nFALL TRENDS',
                                              style: SafeGoogleFont (
                                                'Tenor Sans',
                                                fontSize: 14*ffem,
                                                fontWeight: FontWeight.w400,
                                                height: 1.4285714286*ffem/fem,
                                                letterSpacing: 2*fem,
                                                color: Color(0xfffcfcfc),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // autogroupkjf6qEp (Tyw2oiFmUekL21Q8UMKjf6)
                                width: double.infinity,
                                height: 24*fem,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // frame30yrp (5:811)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10*fem, 0*fem),
                                      width: 67*fem,
                                      height: double.infinity,
                                      decoration: BoxDecoration (
                                        border: Border.all(color: Color(0xfff5f5f5)),
                                        borderRadius: BorderRadius.circular(20*fem),
                                      ),
                                      child: Center(
                                        child: Text(
                                          '#Fashion',
                                          style: SafeGoogleFont (
                                            'Tenor Sans',
                                            fontSize: 12*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.6666666667*ffem/fem,
                                            color: Color(0xff888888),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // frame31Enk (5:813)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 156*fem, 0*fem),
                                      width: 48*fem,
                                      height: double.infinity,
                                      decoration: BoxDecoration (
                                        border: Border.all(color: Color(0xfff5f5f5)),
                                        borderRadius: BorderRadius.circular(20*fem),
                                      ),
                                      child: Center(
                                        child: Text(
                                          '#Tips',
                                          style: SafeGoogleFont (
                                            'Tenor Sans',
                                            fontSize: 12*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.6666666667*ffem/fem,
                                            color: Color(0xff888888),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Text(
                                      // daysagovfa (5:816)
                                      '4 days ago',
                                      style: SafeGoogleFont (
                                        'Tenor Sans',
                                        fontSize: 12*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.6666666667*ffem/fem,
                                        color: Color(0xff888888),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 28*fem,
                        ),
                        Container(
                          // postqXe (5:817)
                          width: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // autogrouppheybFv (Tyw3CT6swvhgziThVtphEY)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 7.67*fem),
                                padding: EdgeInsets.fromLTRB(0*fem, 12.92*fem, 0*fem, 0.29*fem),
                                width: double.infinity,
                                decoration: BoxDecoration (
                                  image: DecorationImage (
                                    fit: BoxFit.cover,
                                    image: AssetImage (
                                      'assets/page-1/images/rectangle-434-bg-yHS.png',
                                    ),
                                  ),
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  children: [
                                    Container(
                                      // bookmarkH8k (I5:817;5:815)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 11*fem, 86.42*fem),
                                      width: 12*fem,
                                      height: 13.76*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/bookmark-7sn.png',
                                        width: 12*fem,
                                        height: 13.76*fem,
                                      ),
                                    ),
                                    Container(
                                      // autogroupaekgoMz (Tyw3HnHL7J5Ny8xaaiaEkG)
                                      padding: EdgeInsets.fromLTRB(14*fem, 33.1*fem, 27*fem, 13.5*fem),
                                      width: double.infinity,
                                      height: 86.61*fem,
                                      decoration: BoxDecoration (
                                        gradient: LinearGradient (
                                          begin: Alignment(-0.177, 1),
                                          end: Alignment(-0.177, -0.979),
                                          colors: <Color>[Color(0xff111111), Color(0xfc111111), Color(0xf5111111), Color(0xea111111), Color(0xd9111111), Color(0xc3111111), Color(0xaa111111), Color(0x8e111111), Color(0x70111111), Color(0x54111111), Color(0x3b111111), Color(0x25111111), Color(0x14111111), Color(0x09111111), Color(0x02111111), Color(0x00111111)],
                                          stops: <double>[0, 0.067, 0.133, 0.2, 0.267, 0.333, 0.4, 0.467, 0.533, 0.6, 0.667, 0.733, 0.8, 0.867, 0.933, 1],
                                        ),
                                      ),
                                      child: Center(
                                        // styleguidethebiggestfalltrends (I5:817;5:810)
                                        child: SizedBox(
                                          child: Container(
                                            constraints: BoxConstraints (
                                              maxWidth: 302*fem,
                                            ),
                                            child: Text(
                                              '2023 STYLE GUIDE: THE BIGGEST \nFALL TRENDS',
                                              style: SafeGoogleFont (
                                                'Tenor Sans',
                                                fontSize: 14*ffem,
                                                fontWeight: FontWeight.w400,
                                                height: 1.4285714286*ffem/fem,
                                                letterSpacing: 2*fem,
                                                color: Color(0xfffcfcfc),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // autogroupmp7nD4L (Tyw3P2dazCqPM9WdjzmP7N)
                                width: double.infinity,
                                height: 24*fem,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // frame30Xqi (I5:817;5:811)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10*fem, 0*fem),
                                      width: 67*fem,
                                      height: double.infinity,
                                      decoration: BoxDecoration (
                                        border: Border.all(color: Color(0xfff5f5f5)),
                                        borderRadius: BorderRadius.circular(20*fem),
                                      ),
                                      child: Center(
                                        child: Text(
                                          '#Fashion',
                                          style: SafeGoogleFont (
                                            'Tenor Sans',
                                            fontSize: 12*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.6666666667*ffem/fem,
                                            color: Color(0xff888888),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // frame31PN8 (I5:817;5:813)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 156*fem, 0*fem),
                                      width: 48*fem,
                                      height: double.infinity,
                                      decoration: BoxDecoration (
                                        border: Border.all(color: Color(0xfff5f5f5)),
                                        borderRadius: BorderRadius.circular(20*fem),
                                      ),
                                      child: Center(
                                        child: Text(
                                          '#Tips',
                                          style: SafeGoogleFont (
                                            'Tenor Sans',
                                            fontSize: 12*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.6666666667*ffem/fem,
                                            color: Color(0xff888888),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Text(
                                      // daysagosHJ (I5:817;5:816)
                                      '4 days ago',
                                      style: SafeGoogleFont (
                                        'Tenor Sans',
                                        fontSize: 12*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.6666666667*ffem/fem,
                                        color: Color(0xff888888),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 28*fem,
                        ),
                        Container(
                          // postzcp (5:818)
                          width: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // autogroupbzg4MCU (Tyw3jX3So6BKJi3tqrBZg4)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 7.67*fem),
                                padding: EdgeInsets.fromLTRB(0*fem, 12.92*fem, 0*fem, 0.29*fem),
                                width: double.infinity,
                                decoration: BoxDecoration (
                                  image: DecorationImage (
                                    fit: BoxFit.cover,
                                    image: AssetImage (
                                      'assets/page-1/images/rectangle-434-bg.png',
                                    ),
                                  ),
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  children: [
                                    Container(
                                      // bookmarkdQt (I5:818;5:815)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 11*fem, 86.42*fem),
                                      width: 12*fem,
                                      height: 13.76*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/bookmark-fUt.png',
                                        width: 12*fem,
                                        height: 13.76*fem,
                                      ),
                                    ),
                                    Container(
                                      // autogroup2k9sLKJ (Tyw3pGQXyFFE8EvzTs2K9S)
                                      padding: EdgeInsets.fromLTRB(14*fem, 33.1*fem, 27*fem, 13.5*fem),
                                      width: double.infinity,
                                      height: 86.61*fem,
                                      decoration: BoxDecoration (
                                        gradient: LinearGradient (
                                          begin: Alignment(-0.177, 1),
                                          end: Alignment(-0.177, -0.979),
                                          colors: <Color>[Color(0xff111111), Color(0xfc111111), Color(0xf5111111), Color(0xea111111), Color(0xd9111111), Color(0xc3111111), Color(0xaa111111), Color(0x8e111111), Color(0x70111111), Color(0x54111111), Color(0x3b111111), Color(0x25111111), Color(0x14111111), Color(0x09111111), Color(0x02111111), Color(0x00111111)],
                                          stops: <double>[0, 0.067, 0.133, 0.2, 0.267, 0.333, 0.4, 0.467, 0.533, 0.6, 0.667, 0.733, 0.8, 0.867, 0.933, 1],
                                        ),
                                      ),
                                      child: Center(
                                        // styleguidethebiggestfalltrends (I5:818;5:810)
                                        child: SizedBox(
                                          child: Container(
                                            constraints: BoxConstraints (
                                              maxWidth: 302*fem,
                                            ),
                                            child: Text(
                                              '2023 STYLE GUIDE: THE BIGGEST \nFALL TRENDS',
                                              style: SafeGoogleFont (
                                                'Tenor Sans',
                                                fontSize: 14*ffem,
                                                fontWeight: FontWeight.w400,
                                                height: 1.4285714286*ffem/fem,
                                                letterSpacing: 2*fem,
                                                color: Color(0xfffcfcfc),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // autogroupyg4g1Jx (Tyw3uGGCznABj1eZrWYG4g)
                                width: double.infinity,
                                height: 24*fem,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // frame309g4 (I5:818;5:811)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10*fem, 0*fem),
                                      width: 67*fem,
                                      height: double.infinity,
                                      decoration: BoxDecoration (
                                        border: Border.all(color: Color(0xfff5f5f5)),
                                        borderRadius: BorderRadius.circular(20*fem),
                                      ),
                                      child: Center(
                                        child: Text(
                                          '#Fashion',
                                          style: SafeGoogleFont (
                                            'Tenor Sans',
                                            fontSize: 12*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.6666666667*ffem/fem,
                                            color: Color(0xff888888),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // frame313WY (I5:818;5:813)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 156*fem, 0*fem),
                                      width: 48*fem,
                                      height: double.infinity,
                                      decoration: BoxDecoration (
                                        border: Border.all(color: Color(0xfff5f5f5)),
                                        borderRadius: BorderRadius.circular(20*fem),
                                      ),
                                      child: Center(
                                        child: Text(
                                          '#Tips',
                                          style: SafeGoogleFont (
                                            'Tenor Sans',
                                            fontSize: 12*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.6666666667*ffem/fem,
                                            color: Color(0xff888888),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Text(
                                      // daysagoKDA (I5:818;5:816)
                                      '4 days ago',
                                      style: SafeGoogleFont (
                                        'Tenor Sans',
                                        fontSize: 12*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.6666666667*ffem/fem,
                                        color: Color(0xff888888),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 28*fem,
                        ),
                        Container(
                          // posteWL (5:819)
                          width: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // autogroupys7aPD2 (Tyw4Gaz1eFewche6BoYS7a)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 7.67*fem),
                                padding: EdgeInsets.fromLTRB(0*fem, 12.92*fem, 0*fem, 0.29*fem),
                                width: double.infinity,
                                decoration: BoxDecoration (
                                  image: DecorationImage (
                                    fit: BoxFit.cover,
                                    image: AssetImage (
                                      'assets/page-1/images/rectangle-434-bg-1SG.png',
                                    ),
                                  ),
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  children: [
                                    Container(
                                      // bookmark3oN (I5:819;5:815)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 11*fem, 86.42*fem),
                                      width: 12*fem,
                                      height: 13.76*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/bookmark.png',
                                        width: 12*fem,
                                        height: 13.76*fem,
                                      ),
                                    ),
                                    Container(
                                      // autogroup4p2pa2c (Tyw4MaqgfnZuDUMfaT4P2p)
                                      padding: EdgeInsets.fromLTRB(14*fem, 33.1*fem, 27*fem, 13.5*fem),
                                      width: double.infinity,
                                      height: 86.61*fem,
                                      decoration: BoxDecoration (
                                        gradient: LinearGradient (
                                          begin: Alignment(-0.177, 1),
                                          end: Alignment(-0.177, -0.979),
                                          colors: <Color>[Color(0xff111111), Color(0xfc111111), Color(0xf5111111), Color(0xea111111), Color(0xd9111111), Color(0xc3111111), Color(0xaa111111), Color(0x8e111111), Color(0x70111111), Color(0x54111111), Color(0x3b111111), Color(0x25111111), Color(0x14111111), Color(0x09111111), Color(0x02111111), Color(0x00111111)],
                                          stops: <double>[0, 0.067, 0.133, 0.2, 0.267, 0.333, 0.4, 0.467, 0.533, 0.6, 0.667, 0.733, 0.8, 0.867, 0.933, 1],
                                        ),
                                      ),
                                      child: Center(
                                        // styleguidethebiggestfalltrends (I5:819;5:810)
                                        child: SizedBox(
                                          child: Container(
                                            constraints: BoxConstraints (
                                              maxWidth: 302*fem,
                                            ),
                                            child: Text(
                                              '2023 STYLE GUIDE: THE BIGGEST \nFALL TRENDS',
                                              style: SafeGoogleFont (
                                                'Tenor Sans',
                                                fontSize: 14*ffem,
                                                fontWeight: FontWeight.w400,
                                                height: 1.4285714286*ffem/fem,
                                                letterSpacing: 2*fem,
                                                color: Color(0xfffcfcfc),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // autogrouph7jwSyv (Tyw4Tafh6ps3wCRA3dH7jW)
                                width: double.infinity,
                                height: 24*fem,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // frame30PPN (I5:819;5:811)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10*fem, 0*fem),
                                      width: 67*fem,
                                      height: double.infinity,
                                      decoration: BoxDecoration (
                                        border: Border.all(color: Color(0xfff5f5f5)),
                                        borderRadius: BorderRadius.circular(20*fem),
                                      ),
                                      child: Center(
                                        child: Text(
                                          '#Fashion',
                                          style: SafeGoogleFont (
                                            'Tenor Sans',
                                            fontSize: 12*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.6666666667*ffem/fem,
                                            color: Color(0xff888888),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // frame31VBW (I5:819;5:813)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 156*fem, 0*fem),
                                      width: 48*fem,
                                      height: double.infinity,
                                      decoration: BoxDecoration (
                                        border: Border.all(color: Color(0xfff5f5f5)),
                                        borderRadius: BorderRadius.circular(20*fem),
                                      ),
                                      child: Center(
                                        child: Text(
                                          '#Tips',
                                          style: SafeGoogleFont (
                                            'Tenor Sans',
                                            fontSize: 12*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.6666666667*ffem/fem,
                                            color: Color(0xff888888),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Text(
                                      // daysagoZSG (I5:819;5:816)
                                      '4 days ago',
                                      style: SafeGoogleFont (
                                        'Tenor Sans',
                                        fontSize: 12*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.6666666667*ffem/fem,
                                        color: Color(0xff888888),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // button6wz (5:820)
                    margin: EdgeInsets.fromLTRB(66*fem, 0*fem, 66*fem, 0*fem),
                    padding: EdgeInsets.fromLTRB(33*fem, 12*fem, 36*fem, 12*fem),
                    width: double.infinity,
                    decoration: BoxDecoration (
                      border: Border.all(color: Color(0xffdedede)),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // submitDFv (I5:820;862:2415)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 19*fem, 0*fem),
                          child: Text(
                            'LOAD MORE',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Tenor Sans',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.5*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                        Container(
                          // plus7cC (I5:820;862:2416)
                          width: 18*fem,
                          height: 18*fem,
                          child: Image.asset(
                            'assets/page-1/images/plus.png',
                            width: 18*fem,
                            height: 18*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // footerFiQ (5:821)
              padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupfxhwakg (Tyw6LH3aRfiuDy1RnhFxhW)
                    padding: EdgeInsets.fromLTRB(29*fem, 23.78*fem, 30*fem, 22.97*fem),
                    width: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // group29v3r (I5:821;639:716)
                          margin: EdgeInsets.fromLTRB(77.5*fem, 0*fem, 76.5*fem, 24*fem),
                          padding: EdgeInsets.fromLTRB(1.6*fem, 2.4*fem, 1.6*fem, 2.4*fem),
                          width: double.infinity,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // twitterpuv (I5:821;560:875)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 49*fem, 0*fem),
                                width: 20.8*fem,
                                height: 16.9*fem,
                                child: Image.asset(
                                  'assets/page-1/images/twitter.png',
                                  width: 20.8*fem,
                                  height: 16.9*fem,
                                ),
                              ),
                              Container(
                                // instagramjGC (I5:821;560:877)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 49*fem, 0*fem),
                                width: 19.2*fem,
                                height: 19.2*fem,
                                child: Image.asset(
                                  'assets/page-1/images/instagram-enc.png',
                                  width: 19.2*fem,
                                  height: 19.2*fem,
                                ),
                              ),
                              Container(
                                // youtubee8G (I5:821;560:881)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                                width: 20.8*fem,
                                height: 17.6*fem,
                                child: Image.asset(
                                  'assets/page-1/images/youtube.png',
                                  width: 20.8*fem,
                                  height: 17.6*fem,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // NKA (I5:821;585:713)
                          margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 18.73*fem),
                          width: 124.96*fem,
                          height: 9.25*fem,
                          child: Image.asset(
                            'assets/page-1/images/-ypk.png',
                            width: 124.96*fem,
                            height: 9.25*fem,
                          ),
                        ),
                        Container(
                          // autogroupn9zxTLc (Tyw61xEmziNih93egzN9zx)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 30.02*fem),
                          width: double.infinity,
                          height: 118*fem,
                          child: Stack(
                            children: [
                              Positioned(
                                // CJC (I5:821;651:912)
                                left: 96.0206298828*fem,
                                top: 106.7641601562*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 124.96*fem,
                                    height: 9.25*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/-S6C.png',
                                      width: 124.96*fem,
                                      height: 9.25*fem,
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // supportopenuidesign60825876080 (I5:821;560:899)
                                left: 0*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 316*fem,
                                    height: 118*fem,
                                    child: Text(
                                      'connect us at : sahilsigh0322@gmail.com\n+88043****77\n24/7 - Everyday\nI have nothing to do i’m super free\n',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Tenor Sans',
                                        fontSize: 16*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.8399999142*ffem/fem,
                                        color: Color(0xff333333),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // autogroupu6qqZY4 (Tyw67nQPrqSWE3DVK5U6QQ)
                          margin: EdgeInsets.fromLTRB(29*fem, 0*fem, 40*fem, 0*fem),
                          width: double.infinity,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Text(
                                // about6Xz (I5:821;560:885)
                                'About',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Tenor Sans',
                                  fontSize: 16*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.5*ffem/fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                              SizedBox(
                                width: 52*fem,
                              ),
                              Text(
                                // contactRKN (I5:821;560:886)
                                'Contact',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Tenor Sans',
                                  fontSize: 16*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.5*ffem/fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                              SizedBox(
                                width: 52*fem,
                              ),
                              Text(
                                // blogxKJ (I5:821;560:887)
                                'Blog',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Tenor Sans',
                                  fontSize: 16*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.5*ffem/fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogrouppctytCx (Tyw6EnCjhP7r4ictrnPctY)
                    width: double.infinity,
                    height: 45.25*fem,
                    decoration: BoxDecoration (
                      color: Color(0x19c4c4c4),
                    ),
                    child: Center(
                      child: Text(
                        'Thanks for visiting i hope you liked our product UI :)',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Tenor Sans',
                          fontSize: 12*ffem,
                          fontWeight: FontWeight.w400,
                          height: 1.5849998792*ffem/fem,
                          color: Color(0xff555555),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}