import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // paymentsuccessDQc (5:1282)
        width: double.infinity,
        height: 778*fem,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Stack(
          children: [
            Positioned(
              // headerLEL (5:1283)
              left: 0*fem,
              top: 0*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(16.31*fem, 19.86*fem, 25*fem, 9.04*fem),
                width: 375*fem,
                height: 60*fem,
                decoration: BoxDecoration (
                  color: Color(0xffffffff),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // menuzpg (I5:1283;424:630)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 102.31*fem, 1.32*fem),
                      width: 23.39*fem,
                      height: 14*fem,
                      child: Image.asset(
                        'assets/page-1/images/menu-Tqa.png',
                        width: 23.39*fem,
                        height: 14*fem,
                      ),
                    ),
                    Opacity(
                      // logoWY8 (I5:1283;658:707)
                      opacity: 0.8,
                      child: Container(
                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 69.65*fem, 0*fem),
                        width: 78.35*fem,
                        height: 31.09*fem,
                        child: Image.asset(
                          'assets/page-1/images/logo.png',
                          width: 78.35*fem,
                          height: 31.09*fem,
                        ),
                      ),
                    ),
                    Container(
                      // searchzy6 (I5:1283;424:634)
                      margin: EdgeInsets.fromLTRB(0*fem, 1.18*fem, 20.97*fem, 0*fem),
                      width: 20*fem,
                      height: 20*fem,
                      child: Image.asset(
                        'assets/page-1/images/search-49e.png',
                        width: 20*fem,
                        height: 20*fem,
                      ),
                    ),
                    Container(
                      // shoppingbagv64 (I5:1283;425:656)
                      margin: EdgeInsets.fromLTRB(0*fem, 2.18*fem, 0*fem, 0*fem),
                      width: 19.03*fem,
                      height: 22.55*fem,
                      child: Image.asset(
                        'assets/page-1/images/shopping-bag-CVe.png',
                        width: 19.03*fem,
                        height: 22.55*fem,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // checkout17W (5:1284)
              left: 118.8319702148*fem,
              top: 93.7473144531*fem,
              child: Align(
                child: SizedBox(
                  width: 139*fem,
                  height: 40*fem,
                  child: Text(
                    'CHECKOUT',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Tenor Sans',
                      fontSize: 18*ffem,
                      fontWeight: FontWeight.w400,
                      height: 2.2222222222*ffem/fem,
                      letterSpacing: 4*fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // fSx (5:1285)
              left: 125.8526611328*fem,
              top: 126.3232421875*fem,
              child: Align(
                child: SizedBox(
                  width: 124.96*fem,
                  height: 9.25*fem,
                  child: Image.asset(
                    'assets/page-1/images/-E24.png',
                    width: 124.96*fem,
                    height: 9.25*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // bbakerstmarylyiY (5:1286)
              left: 34.3415527344*fem,
              top: 173.841796875*fem,
              child: Align(
                child: SizedBox(
                  width: 196*fem,
                  height: 66*fem,
                  child: Text(
                    '606-3727 Ullamcorper. Street\n\nRoseville NH 11523',
                    style: SafeGoogleFont (
                      'Tenor Sans',
                      fontSize: 14*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.5714285714*ffem/fem,
                      color: Color(0xff555555),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // bbakerstmarylGBr (5:1287)
              left: 34.3415527344*fem,
              top: 220.7119140625*fem,
              child: Align(
                child: SizedBox(
                  width: 92*fem,
                  height: 22*fem,
                  child: Text(
                    '(786) 713-8616',
                    style: SafeGoogleFont (
                      'Tenor Sans',
                      fontSize: 14*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.5714285714*ffem/fem,
                      color: Color(0xff555555),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // cassiedonkwYt (5:1288)
              left: 34.3415527344*fem,
              top: 151*fem,
              child: Align(
                child: SizedBox(
                  width: 101*fem,
                  height: 16*fem,
                  child: Text(
                    'Iris Watson',
                    style: SafeGoogleFont (
                      'Tenor Sans',
                      fontSize: 18*ffem,
                      fontWeight: FontWeight.w400,
                      height: 0.8888888889*ffem/fem,
                      color: Color(0xff1a1a1a),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // forward2aL (5:1289)
              left: 333.5*fem,
              top: 202.0085449219*fem,
              child: Align(
                child: SizedBox(
                  width: 5.8*fem,
                  height: 11.61*fem,
                  child: Image.asset(
                    'assets/page-1/images/forward-oFN.png',
                    width: 5.8*fem,
                    height: 11.61*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // mastercardending9Q4 (5:1290)
              left: 96.9798583984*fem,
              top: 289.7429199219*fem,
              child: Align(
                child: SizedBox(
                  width: 188*fem,
                  height: 16*fem,
                  child: Text(
                    'Master Card ending  ••••89',
                    style: SafeGoogleFont (
                      'Tenor Sans',
                      fontSize: 14*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.1428571429*ffem/fem,
                      color: Color(0xff17181a),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // mastercardda8 (5:1291)
              left: 33.8956298828*fem,
              top: 285.3813476562*fem,
              child: Align(
                child: SizedBox(
                  width: 52.15*fem,
                  height: 31.24*fem,
                  child: Image.asset(
                    'assets/page-1/images/mastercard.png',
                    width: 52.15*fem,
                    height: 31.24*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // forwardKxk (5:1302)
              left: 333.5*fem,
              top: 303.9096679688*fem,
              child: Align(
                child: SizedBox(
                  width: 5.8*fem,
                  height: 11.61*fem,
                  child: Image.asset(
                    'assets/page-1/images/forward-zNL.png',
                    width: 5.8*fem,
                    height: 11.61*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // line19dCk (5:1303)
              left: 16*fem,
              top: 275*fem,
              child: Align(
                child: SizedBox(
                  width: 343*fem,
                  height: 1*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0x19000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // line209gt (5:1304)
              left: 16*fem,
              top: 568.0561523438*fem,
              child: Align(
                child: SizedBox(
                  width: 343*fem,
                  height: 1*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0x19000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // line21UjA (5:1305)
              left: 16*fem,
              top: 347.5793457031*fem,
              child: Align(
                child: SizedBox(
                  width: 343*fem,
                  height: 1*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0x19000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // frame28N3r (5:1306)
              left: 33*fem,
              top: 519.5207519531*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(20*fem, 10*fem, 20*fem, 10*fem),
                width: 315*fem,
                height: 36*fem,
                decoration: BoxDecoration (
                  borderRadius: BorderRadius.circular(30*fem),
                ),
                child: Text(
                  'Add promo code',
                  style: SafeGoogleFont (
                    'Tenor Sans',
                    fontSize: 14*ffem,
                    fontWeight: FontWeight.w400,
                    height: 1.1428571429*ffem/fem,
                    color: Color(0xff333333),
                  ),
                ),
              ),
            ),
            Positioned(
              // totalqTE (5:1308)
              left: 16*fem,
              top: 683.7265625*fem,
              child: Align(
                child: SizedBox(
                  width: 60*fem,
                  height: 35*fem,
                  child: Text(
                    'TOTAL',
                    style: SafeGoogleFont (
                      'Tenor Sans',
                      fontSize: 14*ffem,
                      fontWeight: FontWeight.w400,
                      height: 2.4642857143*ffem/fem,
                      letterSpacing: 3*fem,
                      color: Color(0xff333333),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // j2p (5:1309)
              left: 313*fem,
              top: 683.7265625*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 35*fem,
                  child: Text(
                    '\$240',
                    style: SafeGoogleFont (
                      'Tenor Sans',
                      fontSize: 16*ffem,
                      fontWeight: FontWeight.w400,
                      height: 2.15625*ffem/fem,
                      letterSpacing: 3*fem,
                      color: Color(0xffdd8560),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // cartEEU (5:1310)
              left: 16*fem,
              top: 361.5207519531*fem,
              child: Container(
                width: 311.72*fem,
                height: 133.33*fem,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // rectangle344LYQ (I5:1310;700:1440)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.72*fem, 0*fem),
                      width: 100*fem,
                      height: 133.33*fem,
                      child: Image.asset(
                        'assets/page-1/images/rectangle-344.png',
                        fit: BoxFit.cover,
                      ),
                    ),
                    Container(
                      // frame27qVA (I5:1310;700:1476)
                      margin: EdgeInsets.fromLTRB(0*fem, 7*fem, 0*fem, 10.33*fem),
                      width: 201*fem,
                      height: double.infinity,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // frame14Lwi (I5:1310;700:1444)
                            width: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  // lamereihnG (I5:1310;700:1445)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 6*fem),
                                  child: Text(
                                    'LAMEREI',
                                    style: SafeGoogleFont (
                                      'Tenor Sans',
                                      fontSize: 14*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.4285714286*ffem/fem,
                                      letterSpacing: 2*fem,
                                      color: Color(0xff000000),
                                    ),
                                  ),
                                ),
                                Text(
                                  // recycleboucleknitcardiganpinkc (I5:1310;700:1446)
                                  'Recycle Boucle Knit Cardigan Pink',
                                  style: SafeGoogleFont (
                                    'Tenor Sans',
                                    fontSize: 12*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.5*ffem/fem,
                                    color: Color(0xff555555),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // autogroupehda98U (TywGCAHLpMovzbJYJaeHDA)
                            padding: EdgeInsets.fromLTRB(0*fem, 12*fem, 0*fem, 0*fem),
                            width: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  // group212geC (I5:1310;700:1475)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // autogroupcyrgbmA (TywGMVM8bkiPSqB5hXCyrg)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 13.06*fem, 0*fem),
                                        width: 24*fem,
                                        height: 24*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/auto-group-cyrg.png',
                                          width: 24*fem,
                                          height: 24*fem,
                                        ),
                                      ),
                                      Container(
                                        // J9n (I5:1310;700:1474)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 11.94*fem, 0.46*fem),
                                        child: Text(
                                          '1',
                                          style: SafeGoogleFont (
                                            'Tenor Sans',
                                            fontSize: 14*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1*ffem/fem,
                                            color: Color(0xff000000),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // autogroup8whidC4 (TywGRetrnhUX7USPrj8wHi)
                                        width: 24*fem,
                                        height: 24*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/auto-group-8whi.png',
                                          width: 24*fem,
                                          height: 24*fem,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Text(
                                  // N9e (I5:1310;700:1447)
                                  '\$120',
                                  style: SafeGoogleFont (
                                    'Tenor Sans',
                                    fontSize: 15*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.6*ffem/fem,
                                    color: Color(0xffdd8560),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // line2277E (5:1311)
              left: 16*fem,
              top: 510.7607421875*fem,
              child: Align(
                child: SizedBox(
                  width: 343*fem,
                  height: 1*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0x19000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle436c3z (5:1312)
              left: 0*fem,
              top: 0*fem,
              child: Align(
                child: SizedBox(
                  width: 375*fem,
                  height: 800*fem,
                  child: Opacity(
                    opacity: 0.8,
                    child: Container(
                      decoration: BoxDecoration (
                        color: Color(0xcc000000),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // frame32h5S (5:1313)
              left: 16*fem,
              top: 105*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(14.33*fem, 14*fem, 13.23*fem, 28.52*fem),
                width: 343*fem,
                height: 474.52*fem,
                decoration: BoxDecoration (
                  color: Color(0xffffffff),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // autogroupd2ynyoe (TywGv4FCZBGJSFn9fGd2yN)
                      margin: EdgeInsets.fromLTRB(62.17*fem, 0*fem, 0*fem, 39.2*fem),
                      width: double.infinity,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            // autogroupbjctHpL (TywH5PJzLaAktVeh4DBjct)
                            margin: EdgeInsets.fromLTRB(0*fem, 9*fem, 46.5*fem, 0*fem),
                            width: 194*fem,
                            height: 130.31*fem,
                            child: Stack(
                              children: [
                                Positioned(
                                  // orderplacedsuccessfully21E (5:1316)
                                  left: 0*fem,
                                  top: 0*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 194*fem,
                                      height: 80*fem,
                                      child: Text(
                                        'ORDER PLACED\n SUCCESSFULLY',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Tenor Sans',
                                          fontSize: 18*ffem,
                                          fontWeight: FontWeight.w400,
                                          height: 2.2222222222*ffem/fem,
                                          letterSpacing: 4*fem,
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // vectoru52 (5:1322)
                                  left: 72*fem,
                                  top: 84.3078613281*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 46*fem,
                                      height: 46*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/vector-r3r.png',
                                        width: 46*fem,
                                        height: 46*fem,
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // vectorPkt (5:1323)
                                  left: 114.8195800781*fem,
                                  top: 68.2890625*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 16.77*fem,
                                      height: 18.92*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/vector-CTA.png',
                                        width: 16.77*fem,
                                        height: 18.92*fem,
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // vector5tc (5:1324)
                                  left: 59.3286132812*fem,
                                  top: 85.6450195312*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 9.95*fem,
                                      height: 11.22*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/vector-kWL.png',
                                        width: 9.95*fem,
                                        height: 11.22*fem,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // closeCyE (5:1333)
                            width: 12.77*fem,
                            height: 12.77*fem,
                            child: Image.asset(
                              'assets/page-1/images/close.png',
                              width: 12.77*fem,
                              height: 12.77*fem,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // yourpaymentwassuccessMLL (5:1317)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1.1*fem, 1.76*fem),
                      child: Text(
                        'Your payment was success',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Tenor Sans',
                          fontSize: 18*ffem,
                          fontWeight: FontWeight.w400,
                          height: 1.3333333333*ffem/fem,
                          color: Color(0xff333333),
                        ),
                      ),
                    ),
                    Container(
                      // group246zeC (5:1319)
                      margin: EdgeInsets.fromLTRB(80.87*fem, 0*fem, 81.97*fem, 18.52*fem),
                      width: double.infinity,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // paymentidvnk (5:1320)
                            margin: EdgeInsets.fromLTRB(0*fem, 0.21*fem, 7.61*fem, 0*fem),
                            child: Text(
                              'Payment ID',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Tenor Sans',
                                fontSize: 15*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.6*ffem/fem,
                                color: Color(0xff555555),
                              ),
                            ),
                          ),
                          Container(
                            // eTr (5:1321)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0.21*fem),
                            child: Text(
                              '15263541',
                              style: SafeGoogleFont (
                                'Tenor Sans',
                                fontSize: 15*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.6*ffem/fem,
                                color: Color(0xff333333),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // yFE (5:1315)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1.1*fem, 18.76*fem),
                      width: 124.96*fem,
                      height: 9.25*fem,
                      child: Image.asset(
                        'assets/page-1/images/-HYc.png',
                        width: 124.96*fem,
                        height: 9.25*fem,
                      ),
                    ),
                    Container(
                      // rateyourpurchaset7J (5:1318)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0.1*fem, 11.91*fem),
                      child: Text(
                        'Rate your purchase',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Tenor Sans',
                          fontSize: 18*ffem,
                          fontWeight: FontWeight.w400,
                          height: 1.3333333333*ffem/fem,
                          color: Color(0xff333333),
                        ),
                      ),
                    ),
                    Container(
                      // autogroupxsxjnTa (TywHEJDohfzoNfo6qRxSXJ)
                      margin: EdgeInsets.fromLTRB(80.07*fem, 0*fem, 85.38*fem, 43.08*fem),
                      width: double.infinity,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // disappointedhaY (5:1329)
                            width: 30*fem,
                            height: 30*fem,
                            child: Image.asset(
                              'assets/page-1/images/disappointed.png',
                              width: 30*fem,
                              height: 30*fem,
                            ),
                          ),
                          SizedBox(
                            width: 30*fem,
                          ),
                          Container(
                            // happyDon (5:1325)
                            width: 30*fem,
                            height: 30*fem,
                            child: Image.asset(
                              'assets/page-1/images/happy.png',
                              width: 30*fem,
                              height: 30*fem,
                            ),
                          ),
                          SizedBox(
                            width: 30*fem,
                          ),
                          Container(
                            // inloveKrp (5:1327)
                            width: 30*fem,
                            height: 30*fem,
                            child: Image.asset(
                              'assets/page-1/images/in-love.png',
                              width: 30*fem,
                              height: 30*fem,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // autogroupkzrpRex (TywHMDBxFm4TcwFgTbKZrp)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8.83*fem, 0*fem),
                      width: double.infinity,
                      height: 48*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // frame35MHi (5:1331)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8.62*fem, 0*fem),
                            width: 132*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xff000000),
                            ),
                            child: Center(
                              child: Text(
                                'SUBMIT',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Tenor Sans',
                                  fontSize: 16*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.5*ffem/fem,
                                  color: Color(0xfff8f0e7),
                                ),
                              ),
                            ),
                          ),
                          TextButton(
                            // frame36dm2 (5:1332)
                            onPressed: () {},
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Container(
                              width: 166*fem,
                              height: double.infinity,
                              decoration: BoxDecoration (
                                border: Border.all(color: Color(0xffdedede)),
                              ),
                              child: Center(
                                child: Text(
                                  'BACK TO HOME',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Tenor Sans',
                                    fontSize: 16*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.5*ffem/fem,
                                    color: Color(0xff000000),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // button8Bz (5:1334)
              left: 0*fem,
              top: 741*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(119.48*fem, 16.91*fem, 117*fem, 13.09*fem),
                width: 375*fem,
                height: 56*fem,
                decoration: BoxDecoration (
                  color: Color(0xff000000),
                ),
                child: Container(
                  // contentccx (I5:1334;861:2997)
                  width: double.infinity,
                  height: double.infinity,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        // shoppingbagMKe (I5:1334;835:3097)
                        margin: EdgeInsets.fromLTRB(0*fem, 0.84*fem, 25.67*fem, 0*fem),
                        width: 15.86*fem,
                        height: 18.79*fem,
                        child: Image.asset(
                          'assets/page-1/images/shopping-bag-344.png',
                          width: 15.86*fem,
                          height: 18.79*fem,
                        ),
                      ),
                      Text(
                        // checkoutFR2 (I5:1334;835:3096)
                        'CHECKOUT',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Tenor Sans',
                          fontSize: 16*ffem,
                          fontWeight: FontWeight.w400,
                          height: 1.625*ffem/fem,
                          letterSpacing: 0.16*fem,
                          color: Color(0xfffcfcfc),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}