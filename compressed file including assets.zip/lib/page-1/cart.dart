import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // cartJMe (5:931)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroupfox6q6g (Tyw7tQ85UBPXCfoSfRfoX6)
              width: double.infinity,
              height: 584*fem,
              child: Stack(
                children: [
                  Positioned(
                    // cartAPr (5:933)
                    left: 17*fem,
                    top: 42*fem,
                    child: Align(
                      child: SizedBox(
                        width: 68*fem,
                        height: 40*fem,
                        child: Text(
                          'CART',
                          style: SafeGoogleFont (
                            'Tenor Sans',
                            fontSize: 18*ffem,
                            fontWeight: FontWeight.w400,
                            height: 2.2222222222*ffem/fem,
                            letterSpacing: 4*fem,
                            color: Color(0xff333333),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // autogroupk78udHS (Tyw7ieuKGVQenNCmemK78U)
                    left: 16*fem,
                    top: 457*fem,
                    child: Container(
                      width: 348*fem,
                      height: 35*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // subtotalx4p (5:934)
                            margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 120*fem, 0*fem),
                            child: Text(
                              'SUB TOTAL',
                              style: SafeGoogleFont (
                                'Tenor Sans',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.4285714286*ffem/fem,
                                letterSpacing: 2*fem,
                                color: Color(0xff333333),
                              ),
                            ),
                          ),
                          Text(
                            // rs73oday4de (5:935)
                            'RS 73O/DAY',
                            style: SafeGoogleFont (
                              'Tenor Sans',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w400,
                              height: 2.15625*ffem/fem,
                              letterSpacing: 3*fem,
                              color: Color(0xffdd8560),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // closeBTN (5:936)
                    left: 22*fem,
                    top: 16*fem,
                    child: Align(
                      child: SizedBox(
                        width: 12.77*fem,
                        height: 12.77*fem,
                        child: Image.asset(
                          'assets/page-1/images/close-Mxc.png',
                          width: 12.77*fem,
                          height: 12.77*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // autogroupmwhrHmJ (Tyw71WRD5oVRgREbbyMwhr)
                    left: 6*fem,
                    top: 82*fem,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(0*fem, 5.73*fem, 0*fem, 0*fem),
                      width: 345.4*fem,
                      height: 152*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // rectangle325xMe (5:1620)
                            margin: EdgeInsets.fromLTRB(0*fem, 2.27*fem, 24.4*fem, 0*fem),
                            width: 110*fem,
                            height: 144*fem,
                            child: Image.asset(
                              'assets/page-1/images/rectangle-325-vDn.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                          Container(
                            // frame275BN (I5:937;700:1476)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 10.27*fem),
                            width: 211*fem,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // frame14QDe (I5:937;700:1444)
                                  width: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // lamereiYak (I5:937;700:1445)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 6*fem),
                                        constraints: BoxConstraints (
                                          maxWidth: 111*fem,
                                        ),
                                        child: Text(
                                          'MOSCHINO \nHANDBAG',
                                          style: SafeGoogleFont (
                                            'Tenor Sans',
                                            fontSize: 14*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.4285714286*ffem/fem,
                                            letterSpacing: 2*fem,
                                            color: Color(0xff000000),
                                          ),
                                        ),
                                      ),
                                      Text(
                                        // recycleboucleknitcardiganpinkp (I5:937;700:1446)
                                        'Brandnew 2021 model cv213 handbag',
                                        style: SafeGoogleFont (
                                          'Tenor Sans',
                                          fontSize: 12*ffem,
                                          fontWeight: FontWeight.w400,
                                          height: 1.5*ffem/fem,
                                          color: Color(0xff555555),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // autogroupjovaMHJ (Tyw7EqNLVDvecUUoK2joVA)
                                  padding: EdgeInsets.fromLTRB(0*fem, 12*fem, 0*fem, 0*fem),
                                  width: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // group212VeQ (I5:937;700:1475)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // autogroupn7kkEbz (Tyw7Nq91jGzBa7E7wGN7kk)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 13.06*fem, 0*fem),
                                              width: 24*fem,
                                              height: 24*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/auto-group-n7kk.png',
                                                width: 24*fem,
                                                height: 24*fem,
                                              ),
                                            ),
                                            Container(
                                              // xH6 (I5:937;700:1474)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 11.94*fem, 0.46*fem),
                                              child: Text(
                                                '1',
                                                style: SafeGoogleFont (
                                                  'Tenor Sans',
                                                  fontSize: 14*ffem,
                                                  fontWeight: FontWeight.w400,
                                                  height: 1*ffem/fem,
                                                  color: Color(0xff000000),
                                                ),
                                              ),
                                            ),
                                            Container(
                                              // autogroupw5sgsur (Tyw7SaXmVvfuGgmJUkW5Sg)
                                              width: 24*fem,
                                              height: 24*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/auto-group-w5sg.png',
                                                width: 24*fem,
                                                height: 24*fem,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Text(
                                        // Ae4 (I5:937;700:1447)
                                        'Rs 300/day',
                                        style: SafeGoogleFont (
                                          'Tenor Sans',
                                          fontSize: 15*ffem,
                                          fontWeight: FontWeight.w400,
                                          height: 1.6*ffem/fem,
                                          color: Color(0xffdd8560),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // line197JQ (5:939)
                    left: 16*fem,
                    top: 450.3386230469*fem,
                    child: Align(
                      child: SizedBox(
                        width: 343*fem,
                        height: 1*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            color: Color(0x33000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // shippingchargestaxesanddiscoun (5:940)
                    left: 16*fem,
                    top: 500.9340820312*fem,
                    child: Align(
                      child: SizedBox(
                        width: 307*fem,
                        height: 72*fem,
                        child: Text(
                          '*shipping charges, taxes and discount codes   \nare calculated at the time of accounting. ',
                          style: SafeGoogleFont (
                            'Tenor Sans',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.7142857143*ffem/fem,
                            color: Color(0xff888888),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            TextButton(
              // buttontiU (5:941)
              onPressed: () {},
              style: TextButton.styleFrom (
                padding: EdgeInsets.zero,
              ),
              child: Container(
                padding: EdgeInsets.fromLTRB(119.48*fem, 16.91*fem, 117*fem, 13.09*fem),
                width: double.infinity,
                height: 56*fem,
                decoration: BoxDecoration (
                  color: Color(0xff000000),
                ),
                child: Container(
                  // contentP9S (I5:941;861:2997)
                  width: double.infinity,
                  height: double.infinity,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        // shoppingbagWzk (I5:941;835:3097)
                        margin: EdgeInsets.fromLTRB(0*fem, 0.84*fem, 25.67*fem, 0*fem),
                        width: 15.86*fem,
                        height: 18.79*fem,
                        child: Image.asset(
                          'assets/page-1/images/shopping-bag-7da.png',
                          width: 15.86*fem,
                          height: 18.79*fem,
                        ),
                      ),
                      Text(
                        // checkoutq1S (I5:941;835:3096)
                        'RENT NOW',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Tenor Sans',
                          fontSize: 16*ffem,
                          fontWeight: FontWeight.w400,
                          height: 1.625*ffem/fem,
                          letterSpacing: 0.16*fem,
                          color: Color(0xfffcfcfc),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}