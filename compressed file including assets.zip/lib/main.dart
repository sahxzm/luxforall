import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';
import 'package:myapp/page-1/home-page.dart';
// import 'package:myapp/page-1/bloggrid-view.dart';
// import 'package:myapp/page-1/cart.dart';
// import 'package:myapp/page-1/checkout.dart';
// import 'package:myapp/page-1/checkout-CoJ.dart';
// import 'package:myapp/page-1/add-new-address.dart';
// import 'package:myapp/page-1/payment-success.dart';
// import 'package:myapp/page-1/product-detaillayout2.dart';
// import 'package:myapp/page-1/icon-arrow-left.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
	@override
	Widget build(BuildContext context) {
	return MaterialApp(
		title: 'Flutter',
		debugShowCheckedModeBanner: false,
		scrollBehavior: MyCustomScrollBehavior(),
		theme: ThemeData(
		primarySwatch: Colors.blue,
		),
		home: Scaffold(
		body: SingleChildScrollView(
			child: Scene(),
		),
		),
	);
	}
}
